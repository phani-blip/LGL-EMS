/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { 
  Users, 
  CheckCircle, 
  AlertTriangle, 
  ArrowUpRight, 
  ArrowDownLeft,
  Download, 
  Building, 
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Search,
  DollarSign,
  Receipt,
  Trash2,
  Eye,
  X,
  Clock,
  Calendar,
  ClipboardList,
  Layers
} from "lucide-react";
import { Employee, EmployeeSummary, ExpenseTransaction } from "../types";
import { 
  calculateEmployeeSummary, 
  exportDashboardToCSV, 
  exportExpensesToCSV, 
  downloadCSV,
  detectConsecutiveUnderpaid
} from "../utils/lcaCalcs";

interface DashboardViewProps {
  employees: Employee[];
  year: number;
  onYearChange: (yr: number) => void;
  onSelectEmployee: (id: string | null) => void;
  onUpdateEmployee: (updatedEmp: Employee) => void;
  onAddActivity?: (actionType: string, employeeName: string, details: string) => void;
  calculationMode?: "ytd" | "full";
  onCalculationModeChange?: (mode: "ytd" | "full") => void;
}

export default function DashboardView({
  employees,
  year,
  onYearChange,
  onSelectEmployee,
  onUpdateEmployee,
  onAddActivity,
  calculationMode = "ytd",
  onCalculationModeChange,
}: DashboardViewProps) {
  const [dashboardTab, setDashboardTab] = useState<"payroll" | "expenses">("payroll");
  const [statusFilter, setStatusFilter] = useState<string>("All"); // All, Compliant, Underpaid
  
  // Expense Checkboxes / Bulk actions state
  const [selectedTxnIds, setSelectedTxnIds] = useState<string[]>([]);
  
  // Expense Filters
  const [expenseSearch, setExpenseSearch] = useState<string>("");
  const [actualExpenseSearch, setActualExpenseSearch] = useState<string>("");
  const [showDashboardSuggestions, setShowDashboardSuggestions] = useState<boolean>(false);
  const [expenseFlowFilter, setExpenseFlowFilter] = useState<string>("All"); // All, Disbursed, Returned
  const [selectedTxnForDetails, setSelectedTxnForDetails] = useState<{
    employeeName: string;
    employeeId: string;
    employeeUid: string;
    txn: ExpenseTransaction;
  } | null>(null);

  // Helper to extract year from date string (supports MM/DD/YYYY and YYYY-MM-DD)
  const getTransactionYear = (dateStr: string): number => {
    if (!dateStr) return 0;
    // Check for MM/DD/YYYY format
    const partsMdy = dateStr.split("/");
    if (partsMdy.length === 3) {
      return parseInt(partsMdy[2]);
    }
    // Check for YYYY-MM-DD format
    const partsYmd = dateStr.split("-");
    if (partsYmd.length === 3 && partsYmd[0].length === 4) {
      return parseInt(partsYmd[0]);
    }
    try {
      return new Date(dateStr).getFullYear();
    } catch {
      return 0;
    }
  };

  // Compute LCA summary for every employee
  const summaries = useMemo(() => {
    return employees.map(emp => calculateEmployeeSummary(emp, year, calculationMode));
  }, [employees, year, calculationMode]);

  // Apply filters for Payroll
  const filteredSummaries = useMemo(() => {
    return summaries.filter(s => {
      const hasDiscrepancy = s.hasDiscrepancies;
      const consecutiveAlert = detectConsecutiveUnderpaid(s);
      const matchStatus = 
        statusFilter === "All" ||
        (statusFilter === "Compliant" && !hasDiscrepancy) ||
        (statusFilter === "Underpaid" && hasDiscrepancy) ||
        (statusFilter === "Critical" && consecutiveAlert.hasAlert);
      return matchStatus;
    });
  }, [summaries, statusFilter]);

  // Global aggregate metrics for Payroll
  const stats = useMemo(() => {
    const totalCount = summaries.length;
    let compliantCount = 0;
    let underpaidCount = 0;
    let totalLCA = 0;
    let totalPayroll = 0;

    summaries.forEach(s => {
      if (s.hasDiscrepancies) {
        underpaidCount++;
      } else {
        compliantCount++;
      }
      totalLCA += s.expectedAnnualLCA;
      totalPayroll += s.actualAnnualPayroll;
    });

    const netVariance = totalPayroll - totalLCA;

    return {
      totalCount,
      compliantCount,
      underpaidCount,
      totalLCA,
      totalPayroll,
      netVariance,
    };
  }, [summaries]);

  // Gather year-filtered Expense transactions for all employees
  const allYearTransactions = useMemo(() => {
    const list: {
      employee: Employee;
      txn: ExpenseTransaction;
    }[] = [];

    employees.forEach(emp => {
      const txns = emp.expenseTransactions || [];
      txns.forEach(txn => {
        if (getTransactionYear(txn.date) === year) {
          list.push({ employee: emp, txn });
        }
      });
    });

    // Sort by transaction date descending
    return list.sort((a, b) => new Date(b.txn.date).getTime() - new Date(a.txn.date).getTime());
  }, [employees, year]);

  // Global aggregate metrics for Expenses
  const expenseStats = useMemo(() => {
    let disbursed = 0;
    let returned = 0;
    allYearTransactions.forEach(({ txn }) => {
      if (txn.amount < 0) {
        disbursed += Math.abs(txn.amount);
      } else {
        returned += txn.amount;
      }
    });
    const netOutstanding = disbursed - returned;
    return {
      disbursed,
      returned,
      netOutstanding,
      count: allYearTransactions.length
    };
  }, [allYearTransactions]);

  // Aggregate Expenses per Employee (For chart)
  const employeeExpenseStats = useMemo(() => {
    const map = new Map<string, { employee: Employee; disbursed: number; returned: number; outstanding: number }>();
    
    allYearTransactions.forEach(({ employee, txn }) => {
      let statsObj = map.get(employee.id);
      if (!statsObj) {
        statsObj = { employee, disbursed: 0, returned: 0, outstanding: 0 };
        map.set(employee.id, statsObj);
      }
      if (txn.amount < 0) {
        statsObj.disbursed += Math.abs(txn.amount);
      } else {
        statsObj.returned += txn.amount;
      }
    });

    map.forEach(val => {
      val.outstanding = val.disbursed - val.returned;
    });

    return Array.from(map.values()).sort((a, b) => b.disbursed - a.disbursed);
  }, [allYearTransactions]);

  // Filtered Expenses for Ledger Table
  const filteredExpenses = useMemo(() => {
    return allYearTransactions.filter(({ employee, txn }) => {
      let matchFlow = false;
      if (expenseFlowFilter === "All") {
        matchFlow = true;
      } else if (expenseFlowFilter === "Disbursed") {
        matchFlow = txn.amount < 0;
      } else if (expenseFlowFilter === "Returned") {
        matchFlow = txn.amount > 0;
      } else if (expenseFlowFilter === "Outstanding") {
        const stats = employeeExpenseStats.find(s => s.employee.id === employee.id);
        matchFlow = stats ? stats.outstanding !== 0 : false;
      }

      const q = actualExpenseSearch.trim().toLowerCase();
      const matchSearch =
        !q ||
        employee.fullName.toLowerCase().includes(q) ||
        employee.employeeId.toLowerCase().includes(q) ||
        txn.details.toLowerCase().includes(q) ||
        (txn.customFields && Object.values(txn.customFields).some(val => String(val).toLowerCase().includes(q)));

      return matchFlow && matchSearch;
    });
  }, [allYearTransactions, expenseFlowFilter, actualExpenseSearch, employeeExpenseStats]);

  // Filtered Outstanding Balances for Ledger view
  const outstandingEmployeeBalances = useMemo(() => {
    const list = employeeExpenseStats.filter(s => s.outstanding !== 0);
    const q = actualExpenseSearch.trim().toLowerCase();
    if (!q) return list;
    return list.filter(s =>
      s.employee.fullName.toLowerCase().includes(q) ||
      s.employee.employeeId.toLowerCase().includes(q)
    );
  }, [employeeExpenseStats, actualExpenseSearch]);

  // Autocomplete suggestions for Expense Search (supports employee names and transaction descriptions)
  const dbSearchSuggestions = useMemo(() => {
    const q = expenseSearch.trim().toLowerCase();
    if (!q) return [];

    // Filter employees with matches in name/id
    const matchedEmployeeNames = employees
      .filter(emp => emp.fullName.toLowerCase().includes(q) || emp.employeeId.toLowerCase().includes(q))
      .map(emp => ({
        type: "employee" as const,
        value: emp.fullName,
        subtext: emp.employeeId,
      }));

    // Filter unique details
    const matchedDetailsSet = new Set<string>();
    const matchedDetailsList: { type: "detail"; value: string; subtext: string }[] = [];
    
    allYearTransactions.forEach(({ txn }) => {
      const details = txn.details;
      if (details.toLowerCase().includes(q) && !matchedDetailsSet.has(details.toLowerCase())) {
        matchedDetailsSet.add(details.toLowerCase());
        matchedDetailsList.push({
          type: "detail" as const,
          value: details,
          subtext: "Transaction Details",
        });
      }
    });

    // Merge and limit
    return [...matchedEmployeeNames.slice(0, 5), ...matchedDetailsList.slice(0, 5)];
  }, [expenseSearch, employees, allYearTransactions]);

  // Checkbox selection and bulk delete action handling helpers
  const isAllSelected = useMemo(() => {
    return filteredExpenses.length > 0 && filteredExpenses.every(({ txn }) => selectedTxnIds.includes(txn.id));
  }, [filteredExpenses, selectedTxnIds]);

  const handleToggleAll = () => {
    if (isAllSelected) {
      // Remove all currently filtered expenses from selection
      const filteredIds = filteredExpenses.map(({ txn }) => txn.id);
      setSelectedTxnIds(prev => prev.filter(id => !filteredIds.includes(id)));
    } else {
      // Add all currently filtered expenses to selection
      const filteredIds = filteredExpenses.map(({ txn }) => txn.id);
      setSelectedTxnIds(prev => {
        const next = [...prev];
        filteredIds.forEach(id => {
          if (!next.includes(id)) {
            next.push(id);
          }
        });
        return next;
      });
    }
  };

  const handleToggleTxn = (txnId: string) => {
    setSelectedTxnIds(prev =>
      prev.includes(txnId) ? prev.filter(id => id !== txnId) : [...prev, txnId]
    );
  };

  const handleBulkDelete = () => {
    if (selectedTxnIds.length === 0) return;
    const confirm = window.confirm(`Are you sure you want to permanently delete these ${selectedTxnIds.length} selected expense transaction(s)?`);
    if (!confirm) return;

    let deleteCount = 0;
    const deletedDetails: string[] = [];

    employees.forEach(emp => {
      const txns = emp.expenseTransactions || [];
      const toDelete = txns.filter(t => selectedTxnIds.includes(t.id));
      if (toDelete.length > 0) {
        const updated = txns.filter(t => !selectedTxnIds.includes(t.id));
        deleteCount += toDelete.length;
        deletedDetails.push(`${toDelete.length} txn(s) from ${emp.fullName}`);
        
        onUpdateEmployee({
          ...emp,
          expenseTransactions: updated,
        });
      }
    });

    if (deleteCount > 0) {
      if (onAddActivity) {
        onAddActivity(
          "Bulk Expenses Deleted",
          "Expense Ledger",
          `Permanently deleted ${deleteCount} selected expense entries in one bulk action (${deletedDetails.join(", ")})`
        );
      }
      setSelectedTxnIds([]);
    }
  };

  const handleExportDashboard = () => {
    if (dashboardTab === "payroll") {
      const csvContent = exportDashboardToCSV(summaries, year);
      downloadCSV(csvContent, `lca_payroll_audit_dashboard_${year}.csv`);
    } else {
      const csvContent = exportExpensesToCSV(employees);
      downloadCSV(csvContent, `all_employees_expenses_ledger_${year}.csv`);
    }
  };

  return (
    <div id="dashboard_view_pane" className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50 font-sans text-slate-700">
      
      {/* View Header with title & Year Selection */}
      <div id="dashboard_title_bar" className="flex flex-col sm:flex-row sm:items-center sm:justify-end gap-4 border-b border-slate-200 pb-5 animate-fade-in">

        <div className="flex flex-wrap items-center gap-3.5">
          {onCalculationModeChange && (
            <div className="flex items-center gap-1">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">Scope:</span>
              <div id="calculation_mode_toggle" className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200">
                <button
                  type="button"
                  id="calc_mode_btn_ytd"
                  onClick={() => onCalculationModeChange("ytd")}
                  className={`px-3 py-1 text-[10px] font-extrabold rounded-md transition-all cursor-pointer leading-tight uppercase ${
                    calculationMode === "ytd"
                      ? "bg-white text-indigo-700 shadow-sm"
                      : "text-slate-400 hover:text-slate-650"
                  }`}
                  title="Limit expected annual/monthly wage difference check to YTD (Year-to-Date) up to current month"
                >
                  Till Date
                </button>
                <button
                  type="button"
                  id="calc_mode_btn_full"
                  onClick={() => onCalculationModeChange("full")}
                  className={`px-3 py-1 text-[10px] font-extrabold rounded-md transition-all cursor-pointer leading-tight uppercase ${
                    calculationMode === "full"
                      ? "bg-white text-indigo-700 shadow-sm"
                      : "text-slate-400 hover:text-slate-650"
                  }`}
                  title="Evaluate compliance based on full-year targets"
                >
                  Full Year
                </button>
              </div>
            </div>
          )}

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">Fiscal Year:</span>
            <select
              id="dashboard_year_picker"
              value={year}
              onChange={(e) => onYearChange(Number(e.target.value))}
              className="h-9 px-3 bg-white hover:border-slate-300 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 shadow-sm transition-all cursor-pointer"
            >
              {[2025, 2026, 2027].map(yr => (
                <option key={yr} value={yr}>{yr} Audit Cycle</option>
              ))}
            </select>
          </div>

          <button
            id="export_dashboard_csv_btn"
            onClick={handleExportDashboard}
            disabled={employees.length === 0}
            className="h-9 px-4 bg-white hover:bg-slate-50 hover:border-slate-300 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-sm transition-all"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Segment switcher */}
      <div id="dashboard_segment_tabs" className="flex border border-slate-200/70 bg-white p-1 rounded-2xl shadow-sm">
        <button
          id="dashboard_tab_payroll"
          onClick={() => setDashboardTab("payroll")}
          className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
            dashboardTab === "payroll"
              ? "bg-slate-900 text-white shadow-xl shadow-slate-900/10 font-extrabold border-b-2 border-b-indigo-500"
              : "border-transparent text-slate-500 hover:text-slate-900 hover:bg-slate-50"
          }`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${dashboardTab === "payroll" ? "bg-indigo-500 animate-pulse" : "bg-transparent"}`} />
          <span>LCA Audit & Compliance Control</span>
        </button>
        <button
          id="dashboard_tab_expenses"
          onClick={() => setDashboardTab("expenses")}
          className={`flex-1 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
            dashboardTab === "expenses"
              ? "bg-slate-900 text-white shadow-xl shadow-slate-900/10 font-extrabold border-b-2 border-b-indigo-400"
              : "border-transparent text-slate-500 hover:text-slate-900 hover:bg-slate-50"
          }`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${dashboardTab === "expenses" ? "bg-indigo-400 animate-pulse" : "bg-transparent"}`} />
          <span>Workforce Expense Ledger</span>
        </button>
      </div>

      {dashboardTab === "payroll" ? (
        /* ==================== PAYROLL TAB CONTENT ==================== */
        <>
          {/* Aggregate metrics bento stats cards */}
          <div id="dashboard_stats_bento" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Total employees */}
            <div 
              onClick={() => setStatusFilter("All")}
              title="Click to view all employees"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                statusFilter === "All"
                  ? "border-indigo-650 border-l-indigo-600 bg-indigo-50/30 ring-2 ring-indigo-600/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-indigo-600 hover:border-indigo-300 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <Users className="w-32 h-32 text-indigo-600" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Total Employees</p>
                <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                  <Users className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">{stats.totalCount}</p>
              <div className="mt-3 text-xs text-indigo-600 flex items-center gap-1 font-bold">
                <span>Active payroll units</span>
                {statusFilter === "All" && <span className="px-1.5 py-0.5 bg-indigo-600 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

            {/* Compliant Count */}
            <div 
              onClick={() => setStatusFilter("Compliant")}
              title="Click to view compliant records only"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                statusFilter === "Compliant"
                  ? "border-indigo-560 border-l-indigo-500 bg-indigo-50/15 ring-2 ring-indigo-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-indigo-500 hover:border-indigo-400 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <CheckCircle className="w-32 h-32 text-indigo-500" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">LCA Compliance Rate</p>
                <div className="p-1.5 bg-indigo-50 text-indigo-500 rounded-lg">
                  <CheckCircle className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">
                {stats.totalCount > 0 ? `${((stats.compliantCount / stats.totalCount) * 100).toFixed(1)}%` : "100%"}
              </p>
              <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3.5 overflow-hidden">
                <div className="bg-indigo-500 h-full transition-all duration-500" style={{ width: stats.totalCount > 0 ? `${(stats.compliantCount / stats.totalCount) * 100}%` : "100%" }}></div>
              </div>
            </div>

            {/* Underpaid Discrepancies Count */}
            <div 
              onClick={() => setStatusFilter("Underpaid")}
              title="Click to view underpaid records only"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                statusFilter === "Underpaid"
                  ? "border-rose-500 border-l-rose-500 bg-rose-50/30 ring-2 ring-rose-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-rose-500 hover:border-rose-300 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <AlertTriangle className="w-32 h-32 text-rose-500" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Underpaid Alerts</p>
                <div className={`p-1.5 rounded-lg ${stats.underpaidCount > 0 ? "bg-rose-50 text-rose-600 animate-bounce" : "bg-slate-50 text-slate-400"}`}>
                  <AlertTriangle className="w-4 h-4" />
                </div>
              </div>
              <p className={`text-3xl font-black ${stats.underpaidCount > 0 ? "text-rose-600" : "text-slate-900"}`}>
                {stats.underpaidCount}
              </p>
              <div className="mt-3 text-xs flex items-center gap-1 font-bold">
                <span className={stats.underpaidCount > 0 ? "text-rose-650 text-rose-500" : "text-slate-500"}>
                  {stats.underpaidCount > 0 ? "Adjustment Required" : "Zero active alerts"}
                </span>
                {statusFilter === "Underpaid" && <span className="px-1.5 py-0.5 bg-rose-600 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

            {/* Net Audit variance balance */}
            <div 
              onClick={() => setStatusFilter("Underpaid")}
              title="Click to view underpaid discrepancy records"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                statusFilter === "Underpaid"
                  ? "border-rose-500 border-l-rose-600 bg-rose-50/15 ring-2 ring-rose-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-indigo-650 hover:border-slate-350 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.03] pointer-events-none">
                <DollarSign className="w-32 h-32 text-slate-400" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Total Annual Discrepancy</p>
                <div className="p-1.5 bg-slate-50 text-slate-500 rounded-lg">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <p className={`text-2xl font-black tracking-tight ${stats.netVariance >= 0 ? "text-indigo-600" : "text-rose-650 text-rose-600"}`}>
                {stats.netVariance >= 0 ? "+" : "-"}${Math.abs(stats.netVariance).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <div className="mt-3.5 text-xs text-slate-400 font-medium">
                Annualized cumulative differential
              </div>
            </div>

          </div>

          {/* Tabular data filters & main compare list */}
          <div id="dashboard_table_module" className="space-y-4">
            
            {/* Sliders and drop down selectors */}
            <div id="table_filter_dock" className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-100/80">
              <div className="flex items-center gap-1.5 text-xs text-slate-505 text-slate-500 font-semibold uppercase tracking-wider font-mono">
                <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600" />
                <span>Filters:</span>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="text-slate-400">Compliance:</span>
                  <select
                    id="filter_compliance"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-2.5 py-1 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 font-medium"
                  >
                    <option value="All">All statuses</option>
                    <option value="Compliant">Compliant Only</option>
                    <option value="Underpaid">Underpaid Only</option>
                    <option value="Critical">Critical Status (Consecutive Underpaid)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Audit compare index list */}
            <div id="audit_compare_list_scroller" className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm">
              <table className="w-full text-xs text-left text-slate-500 border-collapse">
                <thead className="bg-slate-50 text-slate-400 uppercase text-[10px] font-bold font-mono tracking-wider border-b border-slate-100">
                  <tr>
                    <th scope="col" className="px-5 py-3">Employee Details</th>
                    <th scope="col" className="px-4 py-3 text-right">Mandated LCA Rate</th>
                    <th scope="col" className="px-4 py-3 text-right">Summed Payroll</th>
                    <th scope="col" className="px-4 py-3 text-right">Annual Difference</th>
                    <th scope="col" className="px-5 py-3 text-center">Audit Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSummaries.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-5 py-10 text-center italic text-slate-400 text-xs">
                        No matching compliance summaries available for this year cycle.
                      </td>
                    </tr>
                  ) : (
                    filteredSummaries.map(s => {
                      const isUnderpaid = s.hasDiscrepancies;
                      const consecutiveAlert = detectConsecutiveUnderpaid(s);
                      return (
                        <tr
                          key={s.employee.id}
                          id={`compare_row_${s.employee.id}`}
                          onClick={() => onSelectEmployee(s.employee.id)}
                          className={`cursor-pointer transition-all duration-200 ease-out group border-b border-slate-100 border-l-4 ${
                            consecutiveAlert.hasAlert 
                              ? "bg-rose-50/60 hover:bg-rose-100/70 border-l-rose-500 hover:translate-x-0.5 hover:shadow-xs" 
                              : "border-l-transparent hover:border-l-indigo-500 hover:bg-indigo-50/35 hover:translate-x-0.5 hover:shadow-xs"
                          }`}
                        >
                          {/* Name and ID */}
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`font-semibold transition-colors ${
                                consecutiveAlert.hasAlert 
                                  ? "text-rose-900 font-bold group-hover:text-rose-700" 
                                  : "text-slate-900 group-hover:text-indigo-600"
                              }`}>
                                {s.employee.fullName}
                              </span>
                              {consecutiveAlert.hasAlert && (
                                <span 
                                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-rose-600 text-white rounded text-[9px] font-black uppercase tracking-wide cursor-help shrink-0 shadow-sm" 
                                  title={`Critically underpaid for ${consecutiveAlert.consecutiveMonths.length} consecutive months: ${consecutiveAlert.consecutiveMonths.join(', ')}`}
                                >
                                  ⚠️ {consecutiveAlert.consecutiveMonths.length} Mo STREAK
                                </span>
                              )}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectEmployee(s.employee.id);
                                }}
                                className="inline-flex items-center justify-center font-mono font-bold text-[8px] tracking-wider uppercase bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white px-1.5 py-0.5 rounded transition-all ml-1 border border-indigo-100"
                                title="Go straight to employee profile page"
                              >
                                Go To Profile
                              </button>
                            </div>
                            <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                              {s.employee.employeeId}
                            </div>
                          </td>

                          {/* Expected Annual Rate */}
                          <td className="px-4 py-3.5 text-right font-mono text-slate-900">
                            ${s.expectedAnnualLCA.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                          </td>

                          {/* Cumulative Payroll */}
                          <td className="px-4 py-3.5 text-right font-mono text-slate-900">
                            ${s.actualAnnualPayroll.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                          </td>

                          {/* Difference computation */}
                          <td className="px-4 py-3.5 text-right font-mono">
                            {s.annualDifference >= 0 ? (
                              <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded border border-emerald-100 font-semibold inline-block">
                                +${s.annualDifference.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                              </span>
                            ) : (
                              <span className="text-rose-600 bg-rose-50 px-2 py-1 rounded border border-rose-100 font-bold inline-block">
                                -${Math.abs(s.annualDifference).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                              </span>
                            )}
                          </td>

                          {/* compliance flag */}
                          <td className="px-5 py-3.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {consecutiveAlert.hasAlert ? (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-600 text-white rounded-full font-bold text-[10px] shadow-sm animate-pulse">
                                  <AlertTriangle className="w-3 h-3 text-white" />
                                  <span>Critical Status</span>
                                </span>
                              ) : isUnderpaid ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-50 text-red-600 border border-red-100 rounded-full font-semibold text-[10px]">
                                  <AlertTriangle className="w-3 h-3 text-red-500" />
                                  <span>Underpaid Month(s)</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-600 border border-emerald-150 rounded-full font-semibold text-[10px]">
                                  <CheckCircle className="w-3 h-3 text-emerald-500" />
                                  <span>Compliant</span>
                                </span>
                              )}
                              <ChevronRight className="w-4 h-4 text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* ==================== EXPENSE TAB CONTENT ==================== */
        <>
          {/* Expense bento aggregate cards */}
          <div id="expense_stats_bento" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Cash Paid Out / Disbursed */}
            <div 
              onClick={() => setExpenseFlowFilter("Disbursed")}
              title="Click to view disbursed (advance) transactions"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                expenseFlowFilter === "Disbursed"
                  ? "border-indigo-650 border-l-indigo-600 bg-indigo-50/30 ring-2 ring-indigo-600/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-indigo-600 hover:border-indigo-300 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <ArrowUpRight className="w-32 h-32 text-indigo-600" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Total Disbursed Advance</p>
                <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">
                ${expenseStats.disbursed.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <div className="mt-3 text-xs text-indigo-600 flex items-center gap-1 font-bold">
                <span>Paid outwards ({year})</span>
                {expenseFlowFilter === "Disbursed" && <span className="px-1.5 py-0.5 bg-indigo-600 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

            {/* Total Returned offsets */}
            <div 
              onClick={() => setExpenseFlowFilter("Returned")}
              title="Click to view returned (offset) transactions"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                expenseFlowFilter === "Returned"
                  ? "border-indigo-560 border-l-indigo-500 bg-indigo-50/15 ring-2 ring-indigo-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-indigo-500 hover:border-indigo-400 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <ArrowDownLeft className="w-32 h-32 text-indigo-500" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Total Offsets Returned</p>
                <div className="p-1.5 bg-indigo-50 text-indigo-500 rounded-lg">
                  <ArrowDownLeft className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">
                ${expenseStats.returned.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <div className="mt-3 text-xs text-indigo-500 flex items-center gap-1 font-bold">
                <span>Reclaimed inwards ({year})</span>
                {expenseFlowFilter === "Returned" && <span className="px-1.5 py-0.5 bg-indigo-500 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

            {/* Outstanding Net liability */}
            <div 
              onClick={() => setExpenseFlowFilter("Outstanding")}
              title="Click to view only employees with outstanding balances"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                expenseFlowFilter === "Outstanding"
                  ? "border-amber-500 border-l-amber-500 bg-amber-50/15 ring-2 ring-amber-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-amber-500 hover:border-amber-400 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <DollarSign className="w-32 h-32 text-amber-500" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Net Outstanding Balance</p>
                <div className={`p-1.5 rounded-lg ${expenseStats.netOutstanding > 0 ? "bg-amber-50 text-amber-600 animate-bounce" : "bg-slate-50 text-slate-400"}`}>
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <p className={`text-3xl font-black ${expenseStats.netOutstanding > 0 ? "text-amber-650" : "text-slate-900"}`}>
                ${expenseStats.netOutstanding.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
              <div className="mt-3 text-xs flex items-center gap-1 font-bold">
                <span className={expenseStats.netOutstanding > 0 ? "text-amber-600 animate-pulse" : "text-slate-500"}>
                  {expenseStats.netOutstanding > 0 ? "Reconciliation in progress" : "All accounts balanced"}
                </span>
                {expenseFlowFilter === "Outstanding" && <span className="px-1.5 py-0.5 bg-amber-500 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

            {/* Transactions Logged counter */}
            <div 
              onClick={() => setExpenseFlowFilter("All")}
              title="Click to view all logged transactions"
              className={`rounded-2xl p-5 shadow-sm relative overflow-hidden transition-all cursor-pointer select-none border border-l-4 ${
                expenseFlowFilter === "All"
                  ? "border-slate-800 border-l-slate-700 bg-slate-50 ring-2 ring-slate-500/10 shadow-md scale-[1.01]"
                  : "bg-white border-slate-200 border-l-slate-700 hover:border-slate-400 hover:shadow-md"
              }`}
            >
              <div className="absolute right-0 bottom-0 translate-x-3 translate-y-3 opacity-[0.04] pointer-events-none">
                <ClipboardList className="w-32 h-32 text-slate-600" />
              </div>
              <div className="flex justify-between items-start mb-2">
                <p className="text-[10px] font-bold text-slate-450 uppercase tracking-widest font-mono">Transactions Logged</p>
                <div className="p-1.5 bg-slate-150 bg-slate-100 text-slate-700 rounded-lg">
                  <ClipboardList className="w-4 h-4" />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">{expenseStats.count}</p>
              <div className="mt-3 text-xs text-slate-500 flex items-center gap-1 font-bold">
                <span>Ledger entries tracked</span>
                {expenseFlowFilter === "All" && <span className="px-1.5 py-0.5 bg-slate-700 text-white rounded text-[8px]">Filtered</span>}
              </div>
            </div>

          </div>

          {/* Expense ledger and custom table search & filter dock */}
          <div id="expense_table_module" className="space-y-4">
            
            {/* Filter Dock */}
            <div id="expense_filter_dock" className="flex flex-col md:flex-row items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-150 border-slate-200">
              <form onSubmit={(e) => { e.preventDefault(); }} className="flex flex-1 items-center gap-2 w-full md:w-auto">
                <Search className="w-4 h-4 text-slate-400 shrink-0" />
                <div className="relative w-full md:w-80">
                  <input
                    type="text"
                    placeholder="Type name or details to search..."
                    value={expenseSearch}
                    onFocus={() => setShowDashboardSuggestions(true)}
                    onBlur={() => {
                      setTimeout(() => setShowDashboardSuggestions(false), 200);
                    }}
                    onChange={(e) => {
                      setExpenseSearch(e.target.value);
                      setShowDashboardSuggestions(true);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        setActualExpenseSearch(expenseSearch);
                        setShowDashboardSuggestions(false);
                      }
                    }}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {/* Autocomplete suggestions dropdown */}
                  {showDashboardSuggestions && expenseSearch.trim() !== "" && (
                    <div className="absolute left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-lg shadow-xl z-50 max-h-48 overflow-y-auto py-1 animate-fade-in text-left">
                      {dbSearchSuggestions.length === 0 ? (
                        <div className="px-3 py-2 text-xs text-slate-400 italic">
                          No matching suggestions found
                        </div>
                      ) : (
                        dbSearchSuggestions.map((item, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onMouseDown={(e) => e.preventDefault()}
                            onClick={() => {
                              setExpenseSearch(item.value);
                              setActualExpenseSearch(item.value);
                              setShowDashboardSuggestions(false);
                            }}
                            className="w-full text-left px-3 py-1.5 hover:bg-slate-50 flex flex-col cursor-pointer transition-colors border-b border-slate-50/50 last:border-b-0"
                          >
                            <span className="text-xs font-semibold text-slate-700 truncate">{item.value}</span>
                            <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">{item.subtext}</span>
                          </button>
                        ))
                      )}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActualExpenseSearch(expenseSearch);
                    setShowDashboardSuggestions(false);
                  }}
                  className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 cursor-pointer text-nowrap"
                >
                  Search
                </button>
                {actualExpenseSearch && (
                  <button
                    type="button"
                    onClick={() => {
                      setExpenseSearch("");
                      setActualExpenseSearch("");
                    }}
                    className="text-xs text-rose-500 hover:underline font-semibold"
                  >
                    Clear
                  </button>
                )}
              </form>

              <div className="flex flex-wrap items-center gap-4 w-full md:w-auto justify-end">
                {expenseFlowFilter !== "Outstanding" && selectedTxnIds.length > 0 && (
                  <button
                    type="button"
                    onClick={handleBulkDelete}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-lg flex items-center gap-1.5 shadow-sm shadow-rose-600/10 cursor-pointer transition-colors duration-150 animate-fade-in"
                  >
                    <Trash2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Delete Selected ({selectedTxnIds.length})</span>
                  </button>
                )}
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-500">
                  <span className="text-slate-400">Flow Direction:</span>
                  <select
                    id="expense_flow_filter"
                    value={expenseFlowFilter}
                    onChange={(e) => setExpenseFlowFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-800"
                  >
                    <option value="All">All Transactions</option>
                    <option value="Disbursed">Disbursed (Advance)</option>
                    <option value="Returned">Returned (Offset)</option>
                    <option value="Outstanding">Outstanding Net Balance</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Ledger Transaction table */}
            <div id="expense_ledger_scroller" className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm">
              {expenseFlowFilter === "Outstanding" ? (
                <table className="w-full text-xs text-left text-slate-500 border-collapse">
                  <thead className="bg-slate-50 text-slate-400 uppercase text-[10px] font-bold font-mono tracking-wider border-b border-slate-100">
                    <tr>
                      <th scope="col" className="px-5 py-3">Employee</th>
                      <th scope="col" className="px-4 py-3 text-right">Total Disbursed</th>
                      <th scope="col" className="px-4 py-3 text-right">Total Returned</th>
                      <th scope="col" className="px-5 py-3 text-right">Net Outstanding Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {outstandingEmployeeBalances.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-5 py-10 text-center italic text-slate-400 text-xs">
                          No employees with outstanding balances found.
                        </td>
                      </tr>
                    ) : (
                      outstandingEmployeeBalances.map(({ employee, disbursed, returned, outstanding }) => {
                        const isOwed = outstanding > 0;
                        return (
                          <tr
                            key={employee.id}
                            id={`expense_outstanding_row_${employee.id}`}
                            onClick={() => onSelectEmployee(employee.id)}
                            className="hover:bg-indigo-50/35 cursor-pointer transition-all duration-200 ease-out group border-b border-slate-100 border-l-4 border-l-transparent hover:border-l-indigo-500 hover:translate-x-0.5 hover:shadow-xs"
                          >
                            {/* Employee Detail */}
                            <td className="px-5 py-3.5">
                              <div className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                                {employee.fullName}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {employee.employeeId}
                              </div>
                            </td>

                            {/* Total Disbursed */}
                            <td className="px-4 py-3.5 text-right font-mono text-slate-700">
                              ${disbursed.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </td>

                            {/* Total Returned */}
                            <td className="px-4 py-3.5 text-right font-mono text-emerald-700">
                              ${returned.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </td>

                            {/* Outstanding balance representation */}
                            <td className="px-5 py-3.5 text-right font-mono">
                              <span className={`inline-flex items-center gap-1.5 font-bold ${isOwed ? "text-amber-700" : "text-slate-700"}`}>
                                ${outstanding.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                                {isOwed ? (
                                  <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 border border-amber-150 rounded text-[9px] font-bold uppercase tracking-wider font-sans">
                                    Pending
                                  </span>
                                ) : (
                                  <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-150 rounded text-[9px] font-bold uppercase tracking-wider font-sans">
                                    Balanced
                                  </span>
                                )}
                              </span>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              ) : (
                <table className="w-full text-xs text-left text-slate-500 border-collapse">
                  <thead className="bg-slate-50 text-slate-400 uppercase text-[10px] font-bold font-mono tracking-wider border-b border-slate-100">
                    <tr>
                      <th scope="col" className="px-4 py-3 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={isAllSelected}
                          onChange={handleToggleAll}
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer h-3.5 w-3.5"
                        />
                      </th>
                      <th scope="col" className="px-5 py-3">Employee</th>
                      <th scope="col" className="px-4 py-3">Date</th>
                      <th scope="col" className="px-4 py-3">Details</th>
                      <th scope="col" className="px-4 py-3">Flow Type</th>
                      <th scope="col" className="px-4 py-3 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredExpenses.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-5 py-10 text-center italic text-slate-400 text-xs">
                          No matching expense transactions available for this filters arrangement.
                        </td>
                      </tr>
                    ) : (
                      filteredExpenses.map(({ employee, txn }) => {
                        const isDisbursed = txn.amount > 0;
                        const customList = txn.customFields ? Object.entries(txn.customFields) : [];

                        const isSelected = selectedTxnForDetails?.txn.id === txn.id;

                        return (
                          <tr
                            key={txn.id}
                            id={`expense_row_${txn.id}`}
                            onClick={() => setSelectedTxnForDetails({ employeeName: employee.fullName, employeeId: employee.employeeId, employeeUid: employee.id, txn })}
                            className={`cursor-pointer transition-all duration-200 ease-out group border-b border-slate-100 border-l-4 ${
                              isSelected
                                ? "bg-indigo-100/40 border-l-indigo-600 shadow-xs translate-x-0.5 font-medium"
                                : "border-l-transparent hover:border-l-indigo-400 hover:bg-indigo-50/25 hover:translate-x-0.5 hover:shadow-xs"
                            }`}
                          >
                            {/* Selection Checkbox cell */}
                            <td className="px-4 py-3.5 w-10 text-center" onClick={(e) => e.stopPropagation()}>
                              <input
                                type="checkbox"
                                checked={selectedTxnIds.includes(txn.id)}
                                onChange={() => handleToggleTxn(txn.id)}
                                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer h-3.5 w-3.5"
                              />
                            </td>

                            {/* Name and ID */}
                            <td className="px-5 py-3.5">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                                  {employee.fullName}
                                </span>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onSelectEmployee(employee.id);
                                  }}
                                  className="inline-flex items-center justify-center font-mono font-bold text-[8px] tracking-wider uppercase bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white px-1.5 py-0.5 rounded transition-all ml-1 border border-indigo-100"
                                  title="Go straight to employee profile page"
                                >
                                  Go To Profile
                                </button>
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {employee.employeeId}
                              </div>
                            </td>

                            {/* Transaction Date */}
                            <td className="px-4 py-3.5 text-slate-600 font-sans font-medium">
                              {txn.date}
                            </td>

                            {/* Transaction details Description */}
                            <td className="px-4 py-3.5 text-slate-800 font-medium max-w-xs truncate" title={txn.details}>
                              {txn.details}
                            </td>

                            {/* Flow direction Badge */}
                            <td className="px-4 py-3.5">
                              {isDisbursed ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-750 text-indigo-700 border border-indigo-150 rounded-full text-[10px] font-bold">
                                  <ArrowUpRight className="w-3 h-3 text-indigo-500" />
                                  <span>Disbursed</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 text-emerald-755 text-emerald-700 border border-emerald-150 rounded-full text-[10px] font-bold">
                                  <ArrowDownLeft className="w-3 h-3 text-emerald-500" />
                                  <span>Returned</span>
                                </span>
                              )}
                            </td>

                            {/* Flow Amount numerical representation */}
                            <td className={`px-4 py-3.5 text-right font-mono font-bold ${isDisbursed ? 'text-indigo-700' : 'text-emerald-700'}`}>
                              {isDisbursed ? "+" : ""}${txn.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </>
      )}

      {selectedTxnForDetails && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-100 overflow-hidden transform transition-all duration-300 scale-100 flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-50 to-slate-50 px-6 py-4 border-b border-indigo-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide font-mono">Ledger Transaction Record</h3>
                  <span className="text-[10px] text-slate-400 font-mono">ID: {selectedTxnForDetails.txn.id}</span>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setSelectedTxnForDetails(null)}
                className="p-1 px-2.5 hover:bg-slate-200/60 rounded-full text-slate-500 hover:text-slate-700 transition-colors font-mono font-bold text-sm"
              >
                ✕
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-5">
              {/* Employee Quick Info Card */}
              <div className="bg-indigo-50/50 rounded-xl p-4 border border-indigo-100 flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-indigo-455 text-indigo-505 text-indigo-550 uppercase tracking-widest font-mono">Employee details</span>
                  <h4 className="text-base font-bold text-slate-805 text-slate-800 mt-0.5">{selectedTxnForDetails.employeeName}</h4>
                  <p className="text-xs font-mono text-slate-500 mt-0.5">ID Ref: {selectedTxnForDetails.employeeId}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onSelectEmployee(selectedTxnForDetails.employeeUid);
                    setSelectedTxnForDetails(null);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 font-bold text-white rounded-lg text-[11px] shadow-sm transition-all hover:translate-x-0.5 shadow-indigo-100"
                >
                  <span>View Profile</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Transaction Basic Summary */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-xl p-3 border border-slate-150">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">Date Logged</span>
                  <div className="text-xs font-bold font-mono text-slate-700 mt-1">{selectedTxnForDetails.txn.date}</div>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-150">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">Flow Direction</span>
                  <div className="mt-1">
                    {selectedTxnForDetails.txn.amount < 0 ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-rose-50 text-rose-700 border border-rose-150 rounded-full text-[10px] font-bold">
                        <ArrowDownLeft className="w-3 h-3 text-rose-500" />
                        <span>LGL Paid (-)</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-150 rounded-full text-[10px] font-bold">
                        <ArrowUpRight className="w-3 h-3 text-emerald-500" />
                        <span>LGL Received (+)</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Amount Showcase Box */}
              <div className="bg-slate-900 text-white rounded-xl p-4 flex justify-between items-center relative overflow-hidden">
                <div className="absolute top-0 right-0 transform translate-x-3 -translate-y-3 opacity-10 font-bold font-mono text-[100px] leading-none">$</div>
                <div>
                  <span className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider font-mono">Net Transaction Amount</span>
                  <div className="text-2xl font-bold font-mono mt-1 text-slate-50">
                    {selectedTxnForDetails.txn.amount > 0 ? "+" : "-"}${Math.abs(selectedTxnForDetails.txn.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider font-mono">Subtype label</span>
                  <p className="text-xs font-semibold text-slate-300 mt-1">{selectedTxnForDetails.txn.amount < 0 ? "Advance Disbursement" : "Ledger Recoupment Offset"}</p>
                </div>
              </div>

              {/* LGL Calculations Section (Project, Hrs, rate, taxes...) if they exist */}
              {selectedTxnForDetails.txn.customFields && Object.keys(selectedTxnForDetails.txn.customFields).some(k => ["Project", "Hrs", "Rate", "Total", "Employee Tax", "Employer Tax", "Insurance"].includes(k)) && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <div className="flex items-center gap-1.5 pb-1">
                    <span className="text-[10px] font-extrabold text-indigo-700 uppercase tracking-widest font-mono">Calculated Fields Details</span>
                  </div>
                  
                  <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden text-xs">
                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2.5 bg-slate-100/40">
                      <span className="text-slate-500 font-medium">Project Name:</span>
                      <span className="font-bold text-slate-800 text-right">{selectedTxnForDetails.txn.customFields["Project"] || "N/A"}</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2">
                      <span className="text-slate-500 font-medium">Hours Worked (Hrs):</span>
                      <span className="font-mono text-slate-700 text-right">{selectedTxnForDetails.txn.customFields["Hrs"] || "0.00"} hrs</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2">
                      <span className="text-slate-500 font-medium">Hourly Rate:</span>
                      <span className="font-mono text-slate-700 text-right">{selectedTxnForDetails.txn.customFields["Rate"] || "$0.00"} / hr</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2 bg-indigo-50/30">
                      <span className="text-indigo-900 font-semibold">Total Base (Hrs * Rate):</span>
                      <span className="font-mono font-bold text-indigo-750 text-indigo-700 text-right">{selectedTxnForDetails.txn.customFields["Total"] || "$0.00"}</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2">
                      <span className="text-slate-500 font-medium">Employee Tax deduction:</span>
                      <span className="font-mono text-rose-600 text-right">-{selectedTxnForDetails.txn.customFields["Employee Tax"] || "$0.00"}</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2">
                      <span className="text-slate-500 font-medium">Employer Tax deduction:</span>
                      <span className="font-mono text-rose-600 text-right">-{selectedTxnForDetails.txn.customFields["Employer Tax"] || "$0.00"}</span>
                    </div>

                    <div className="grid grid-cols-2 border-b border-slate-100 px-4 py-2">
                      <span className="text-slate-500 font-medium">Insurance deduction:</span>
                      <span className="font-mono text-rose-600 text-right">-{selectedTxnForDetails.txn.customFields["Insurance"] || "$0.00"}</span>
                    </div>

                    {/* Net Calculation Check */}
                    <div className="grid grid-cols-2 px-4 py-2.5 bg-emerald-50/20">
                      <span className="text-emerald-900 font-bold">LGL Net Received:</span>
                      <span className="font-mono font-bold text-emerald-700 text-right">
                        ${Math.abs(selectedTxnForDetails.txn.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Other Custom Parameters / User Columns Section */}
              {selectedTxnForDetails.txn.customFields && Object.keys(selectedTxnForDetails.txn.customFields).filter(key => !["Project", "Hrs", "Rate", "Total", "Employee Tax", "Employer Tax", "Insurance"].includes(key)).length > 0 && (
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest font-mono">Dynamic Custom Fields (Registered Columns)</span>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(selectedTxnForDetails.txn.customFields)
                      .filter(([key]) => !["Project", "Hrs", "Rate", "Total", "Employee Tax", "Employer Tax", "Insurance"].includes(key))
                      .map(([key, val]) => (
                        <div key={key} className="bg-slate-50 border border-slate-150 p-2.5 rounded-lg flex flex-col">
                          <span className="text-[9px] font-bold text-slate-400 font-mono uppercase">{key}</span>
                          <span className="text-xs font-semibold text-slate-800 mt-0.5">{val || "-"}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Transaction Description / Notes Memo */}
              <div className="space-y-1.5 border-t border-slate-100 pt-4">
                <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest font-mono block">Details & Description Notes</span>
                <div className="bg-slate-50 px-4 py-3 rounded-xl border border-slate-150 min-h-[50px] text-slate-700 text-xs font-sans leading-relaxed">
                  {selectedTxnForDetails.txn.details || (
                    <span className="text-slate-400 italic">No notes or description provided with this record.</span>
                  )}
                </div>
              </div>
            </div>

            {/* Sticky Actions Footer */}
            <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-2.5">
              <button 
                type="button"
                onClick={() => setSelectedTxnForDetails(null)}
                className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 rounded-xl font-semibold text-xs transition-all"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
