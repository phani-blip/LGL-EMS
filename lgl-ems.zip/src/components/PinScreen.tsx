/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Lock, Unlock, Eye, EyeOff, ShieldCheck, ShieldAlert, RotateCcw } from "lucide-react";
import { DEFAULT_SECURITY_PIN } from "../data/seedData";

interface PinScreenProps {
  onSuccess: () => void;
  logoSrc?: string;
}

export default function PinScreen({ onSuccess, logoSrc }: PinScreenProps) {
  const [pin, setPin] = useState<string>("");
  const [showPin, setShowPin] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [savedPin, setSavedPin] = useState<string>(() => {
    return localStorage.getItem("lca_verifier_pin") || DEFAULT_SECURITY_PIN;
  });

  const [isSettingNewPin, setIsSettingNewPin] = useState<boolean>(false);
  const [newPinStep, setNewPinStep] = useState<number>(1); // 1 = Current Pin verify, 2 = New Pin, 3 = Confirm
  const [tempNewPin, setTempNewPin] = useState<string>("");
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  useEffect(() => {
    // Clear display status when PIN changes
    if (errorMsg) setErrorMsg("");
    if (successMsg) setSuccessMsg("");
  }, [pin]);

  // Handle keypress natively for desktop accessibility
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isSuccess || showResetConfirm) return;
      if (e.key >= "0" && e.key <= "9") {
        if (pin.length < 6) {
          setPin(prev => prev + e.key);
        }
      } else if (e.key === "Backspace") {
        setPin(prev => prev.slice(0, -1));
      } else if (e.key === "Enter") {
        handleKeyboardSubmit();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [pin, isSuccess, savedPin, showResetConfirm]);

  const handleNumClick = (num: number) => {
    if (pin.length < 6) {
      setPin(prev => prev + String(num));
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPin("");
  };

  const handleKeyboardSubmit = () => {
    verifyAndProceed();
  };

  const verifyAndProceed = () => {
    if (pin === savedPin) {
      setIsSuccess(true);
      setErrorMsg("");
      setTimeout(() => {
        onSuccess();
      }, 700);
    } else {
      setErrorMsg("Incorrect security PIN. Please try again.");
      setPin("");
    }
  };

  const setupNewPin = () => {
    setIsSettingNewPin(true);
    setNewPinStep(1);
    setPin("");
    setErrorMsg("");
  };

  const handleNewPinFlow = () => {
    if (newPinStep === 1) {
      if (pin === savedPin) {
        setNewPinStep(2);
        setPin("");
        setErrorMsg("");
      } else {
        setErrorMsg("Incorrect current PIN.");
        setPin("");
      }
    } else if (newPinStep === 2) {
      if (pin.length < 4) {
        setErrorMsg("PIN must be at least 4 digits.");
      } else {
        setTempNewPin(pin);
        setNewPinStep(3);
        setPin("");
        setErrorMsg("");
      }
    } else if (newPinStep === 3) {
      if (pin === tempNewPin) {
        localStorage.setItem("lca_verifier_pin", pin);
        setSavedPin(pin);
        setIsSettingNewPin(false);
        setPin("");
        setErrorMsg("");
        setSuccessMsg("Security PIN updated successfully!");
        setTimeout(() => setSuccessMsg(""), 4000);
      } else {
        setErrorMsg("PINs do not match. Restarting setup.");
        setNewPinStep(2);
        setPin("");
      }
    }
  };

  return (
    <div id="pin_screen_container" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900 text-white font-sans">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/30 via-slate-900 to-indigo-950 pointer-events-none" />
      
      <div id="pin_card" className="relative w-full max-w-md p-8 mx-4 bg-slate-950/60 backdrop-blur-xl border border-slate-800 rounded-3xl shadow-2xl flex flex-col items-center">
        {/* Company Logo Display */}
        {logoSrc ? (
          <img
            id="company_logo_pin"
            src={logoSrc}
            alt="LGL Technologies Logo"
            className="h-16 w-auto max-w-[280px] mb-6 object-contain bg-transparent"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div id="fallback_logo_pin" className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20 mb-4">
            <ShieldCheck className="w-9 h-9 text-white" />
          </div>
        )}

        <h1 id="app_title_pin" className="text-xl font-semibold tracking-wide text-slate-100">
          LGL EMS
        </h1>
        <p id="app_subtitle_pin" className="text-xs text-slate-400 mt-1 mb-6 uppercase tracking-wider font-mono">
          Internal Expense & LCA Management System
        </p>

        {/* Lock State Visual Indicator */}
        <div id="lock_indicator" className="mb-4">
          {isSuccess ? (
            <div className="w-12 h-12 bg-indigo-500/15 border border-indigo-500/30 text-indigo-500 rounded-full flex items-center justify-center animate-bounce">
              <Unlock className="w-6 h-6 text-indigo-500" />
            </div>
          ) : (
            <div className="w-12 h-12 bg-indigo-600/10 border border-indigo-600/30 text-indigo-600 rounded-full flex items-center justify-center">
              <Lock className="w-6 h-6 text-indigo-600" />
            </div>
          )}
        </div>

        {/* Dynamic header depending on authorization flow */}
        <h2 id="pin_flow_heading" className="text-base font-medium text-slate-200 text-center">
          {isSettingNewPin ? (
            newPinStep === 1 ? "Enter Current PIN to Authorize Change" :
            newPinStep === 2 ? "Enter New Security PIN (4-6 digits)" : "Confirm New Security PIN"
          ) : (
            "Enter Security PIN"
          )}
        </h2>

        {/* PIN Entry Display dots/numbers */}
        <div id="pin_display_wrapper" className="w-full flex flex-col items-center mt-3">
          <div className="relative flex items-center h-12 px-4 bg-slate-900/80 border border-slate-800 rounded-xl w-64 justify-center tracking-widest text-lg font-mono">
            {pin.length === 0 ? (
              <span className="text-sm text-slate-500 italic">Enter PIN...</span>
            ) : showPin ? (
              pin
            ) : (
              "•".repeat(pin.length)
            )}
            
            {pin.length > 0 && (
              <button
                id="toggle_pin_visibility"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 text-slate-400 hover:text-slate-200 transition-colors"
                title="Toggle View PIN"
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            )}
          </div>

          {errorMsg && (
            <div id="pin_error_banner" className="flex items-center gap-1.5 mt-3 text-rose-400 text-xs font-medium bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 rounded-lg">
              <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div id="pin_success_banner" className="flex items-center gap-1.5 mt-3 text-indigo-500 text-xs font-semibold bg-indigo-550/10 border border-indigo-500/20 px-3 py-1.5 rounded-lg">
              <ShieldCheck className="w-4 h-4 shrink-0 text-indigo-500" />
              <span>{successMsg}</span>
            </div>
          )}
        </div>

        {/* Digit Keypad Grid */}
        <div id="pin_keypad_grid" className="grid grid-cols-3 gap-3.5 w-64 mt-6">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
            <button
              key={num}
              id={`keypad_${num}`}
              onClick={() => handleNumClick(num)}
              type="button"
              className="w-full aspect-square bg-slate-900/50 hover:bg-slate-800/80 border border-slate-800/60 rounded-xl flex items-center justify-center text-xl font-medium cursor-pointer transition-all hover:scale-105 active:scale-95"
            >
              {num}
            </button>
          ))}
          <button
            id="keypad_clear"
            onClick={handleClear}
            type="button"
            className="w-full aspect-square text-xs font-semibold uppercase text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-slate-800/40 rounded-xl flex items-center justify-center pointer-events-auto cursor-pointer"
          >
            Clear
          </button>
          <button
            id="keypad_0"
            onClick={() => handleNumClick(0)}
            type="button"
            className="w-full aspect-square bg-slate-900/50 hover:bg-slate-800/80 border border-slate-800/60 rounded-xl flex items-center justify-center text-xl font-medium cursor-pointer transition-all hover:scale-105"
          >
            0
          </button>
          <button
            id="keypad_delete"
            onClick={handleBackspace}
            type="button"
            className="w-full aspect-square text-xs font-semibold uppercase text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-slate-800/40 rounded-xl flex items-center justify-center cursor-pointer"
          >
            Del
          </button>
        </div>

        {/* Enter Validation trigger */}
        <button
          id="pin_submit_btn"
          disabled={pin.length < 4}
          onClick={isSettingNewPin ? handleNewPinFlow : verifyAndProceed}
          className={`w-64 py-3 rounded-xl mt-6 font-semibold text-sm border cursor-pointer select-none transition-all ${
            pin.length >= 4
              ? "bg-indigo-600 hover:bg-indigo-755 hover:border-indigo-700 hover:shadow-indigo-600/20 text-white border-indigo-600 active:scale-98"
              : "bg-slate-900/40 border-slate-800 text-slate-500 cursor-not-allowed"
          }`}
        >
          {isSettingNewPin ? "Continue" : "Authorize Login"}
        </button>

        {/* Cancel actions if modifying PIN */}
        <div id="pin_management_actions" className="mt-6 flex items-center gap-4 text-xs font-mono text-slate-500">
          {isSettingNewPin ? (
            <button
              id="cancel_new_pin"
              onClick={() => {
                setIsSettingNewPin(false);
                setPin("");
                setErrorMsg("");
              }}
              className="hover:text-slate-200 cursor-pointer transition-colors underline"
            >
              Cancel PIN Change
            </button>
          ) : (
            <button
              id="request_new_pin"
              onClick={setupNewPin}
              className="hover:text-slate-300 cursor-pointer transition-colors underline"
            >
              Change Security PIN
            </button>
          )}

          <span className="text-slate-700">|</span>
          
          <button
            id="forgot_pin_trigger"
            onClick={() => {
              setShowResetConfirm(true);
              setErrorMsg("");
              setPin("");
            }}
            className="hover:text-rose-450 text-rose-500 font-bold cursor-pointer transition-colors underline"
            title="Reset to default local PIN"
          >
            Reset PIN
          </button>
        </div>

        {/* Custom PWA / standalone reset confirmation overlay */}
        {showResetConfirm && (
          <div id="reset_pin_confirm_overlay" className="absolute inset-0 bg-slate-950/95 rounded-3xl p-8 flex flex-col items-center justify-center text-center z-20 animate-fadeIn">
            <div className="w-12 h-12 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-full flex items-center justify-center mb-4">
              <RotateCcw className="w-6 h-6 text-rose-500" />
            </div>
            
            <h3 className="text-lg font-bold text-slate-100">Reset Security PIN?</h3>
            <p className="text-xs text-slate-400 mt-2 mb-6 max-w-xs leading-relaxed">
              This will restore the local workstation PIN back to the factory default <span className="font-mono text-indigo-400 font-bold">"{DEFAULT_SECURITY_PIN}"</span>. Only use this if you have forgotten your custom PIN on this device.
            </p>

            <div className="flex flex-col gap-2.5 w-64">
              <button
                type="button"
                id="do_reset_pin_btn"
                onClick={() => {
                  localStorage.setItem("lca_verifier_pin", DEFAULT_SECURITY_PIN);
                  setSavedPin(DEFAULT_SECURITY_PIN);
                  setPin("");
                  setErrorMsg("");
                  setIsSettingNewPin(false);
                  setShowResetConfirm(false);
                  setSuccessMsg(`PIN reset to: ${DEFAULT_SECURITY_PIN}`);
                  setTimeout(() => setSuccessMsg(""), 5000);
                }}
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer border border-rose-600 active:scale-95"
              >
                Yes, Reset PIN to Default
              </button>

              <button
                type="button"
                id="cancel_reset_pin_btn"
                onClick={() => setShowResetConfirm(false)}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-400 font-semibold text-xs rounded-xl transition-all cursor-pointer border border-slate-800 active:scale-95"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
