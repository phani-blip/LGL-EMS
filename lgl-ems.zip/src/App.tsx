/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  Lock, 
  FileText, 
  Upload, 
  Trash2, 
  RotateCcw,
  Sparkles,
  Home,
  History,
  ChevronUp,
  ChevronDown,
  User,
  Activity,
  Moon,
  Sun,
  Search,
  Download
} from "lucide-react";
import { Employee, AuditActivity } from "./types";
import { SEED_EMPLOYEES, DEFAULT_YEAR_SELECTION } from "./data/seedData";
import { downloadCSV, getCSVTemplate } from "./utils/lcaCalcs";

// Components
import PinScreen from "./components/PinScreen";
import EmployeeList from "./components/EmployeeList";
import DashboardView from "./components/DashboardView";
import EmployeeDetailView from "./components/EmployeeDetailView";
import ImportModal from "./components/ImportModal";
import LOGO_SRC from "./assets/images/lgl_logo_new_1779278963726.png";

export default function App() {
  // Authentication security gating state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    // Keep session authenticated during hot reloads for smoother developer review
    return sessionStorage.getItem("lca_session_active") === "true";
  });

  // Global dashboard dark-mode theme controller
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    try {
      const stored = localStorage.getItem("g_tasks_theme");
      if (stored === "dark" || stored === "light") {
        return stored;
      }
    } catch (e) {
      // ignore
    }
    return "light";
  });

  // Keep DOM and sync attributes matching dark mode state
  useEffect(() => {
    try {
      localStorage.setItem("g_tasks_theme", theme);
    } catch (e) {
      console.error("Failed to persist theme", e);
    }
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
      document.body.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
      document.body.classList.remove("dark");
    }
  }, [theme]);

  // Database core state with local storage file persistence
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const local = localStorage.getItem("lca_verifier_employees");
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {
        console.error("Failed to parse local employee storage. Loading seed dataset.", e);
      }
    }
    return SEED_EMPLOYEES;
  });

  // Selected work state
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [selectedYear, setSelectedYear] = useState<number>(DEFAULT_YEAR_SELECTION);
  const [calculationMode, setCalculationMode] = useState<"ytd" | "full">("ytd");
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);

  // Layout preference fixed to Classic Split
  const layoutPreference = "split";

  // Collapsible Audit Timeline Tray expanded state
  const [isTimelineExpanded, setIsTimelineExpanded] = useState<boolean>(false);

  // States for search and filtering of activities (Feature 5)
  const [timelineSearch, setTimelineSearch] = useState<string>("");
  const [timelineFilter, setTimelineFilter] = useState<string>("All");

  // Audit Logs Trail
  const [activities, setActivities] = useState<AuditActivity[]>(() => {
    const local = localStorage.getItem("lca_verifier_activities");
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {
        console.error("Failed to parse local activities storage.", e);
      }
    }
    return [
      {
        id: "act_initial",
        timestamp: new Date().toISOString(),
        actionType: "System Core Initialized",
        employeeName: "System",
        details: "LGL Technologies payroll secure verifier database initialized successfully."
      }
    ];
  });

  // Derived filtered activities for Feature 5
  const filteredActivities = React.useMemo(() => {
    return activities.filter((act) => {
      // 1. Filter match by category badge
      let matchCat = true;
      if (timelineFilter === "Created") {
        matchCat = act.actionType.includes("Created") || act.actionType.includes("Logged") || act.actionType.includes("Added");
      } else if (timelineFilter === "Edited") {
        matchCat = act.actionType.includes("Edited") || act.actionType.includes("Updated") || act.actionType.includes("Modified");
      } else if (timelineFilter === "Deleted") {
        matchCat = act.actionType.includes("Deleted") || act.actionType.includes("Cleared") || act.actionType.includes("Removed");
      } else if (timelineFilter === "Imported") {
        matchCat = act.actionType.includes("Imported");
      }

      // 2. Filter match by search keyword
      const q = timelineSearch.trim().toLowerCase();
      const matchSearch =
        !q ||
        act.actionType.toLowerCase().includes(q) ||
        act.employeeName.toLowerCase().includes(q) ||
        act.details.toLowerCase().includes(q);

      return matchCat && matchSearch;
    });
  }, [activities, timelineFilter, timelineSearch]);

  // Export audit activity logs to CSV helper for Feature 5
  const handleExportTimeline = () => {
    let csv = "Timestamp,Action Type,Employee/Target,Details\n";
    filteredActivities.forEach((act) => {
      const cleanerDetails = act.details.replace(/"/g, '""');
      csv += `"${act.timestamp}","${act.actionType}","${act.employeeName}","${cleanerDetails}"\n`;
    });
    downloadCSV(csv, "system_audit_activities_report.csv");
  };

  // Log new audit trail event
  const handleAddActivity = (actionType: string, employeeName: string, details: string) => {
    const newActivity: AuditActivity = {
      id: `act_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toISOString(),
      actionType,
      employeeName,
      details,
    };
    setActivities(prev => [newActivity, ...prev]);
  };

  // Write changes to localStorage whenever database state is updated
  useEffect(() => {
    localStorage.setItem("lca_verifier_employees", JSON.stringify(employees));
  }, [employees]);

  // Write activities dynamically
  useEffect(() => {
    localStorage.setItem("lca_verifier_activities", JSON.stringify(activities));
  }, [activities]);

  // Handle successful security PIN verification
  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
    sessionStorage.setItem("lca_session_active", "true");
  };

  // Immediate lock button
  const handleLockApp = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem("lca_session_active");
  };

  // Safe database flush & reset
  const handleResetDatabase = () => {
    const confirm = window.confirm("Are you sure you want to restore the default seed database? This will clear all manual CSV imports and modifications.");
    if (confirm) {
      setEmployees(SEED_EMPLOYEES);
      setSelectedEmployeeId(null);
      localStorage.setItem("lca_verifier_employees", JSON.stringify(SEED_EMPLOYEES));
      const initialLogs = [
        {
          id: `act_reset_${Date.now()}`,
          timestamp: new Date().toISOString(),
          actionType: "System Restored",
          employeeName: "System",
          details: "Database and activity trail reset back to original seed audit profiles successfully."
        }
      ];
      setActivities(initialLogs);
      alert("Database successfully reset to standard verification profiles.");
    }
  };

  const handleAddEmployee = (newEmp: Employee) => {
    setEmployees(prev => [newEmp, ...prev]);
    setSelectedEmployeeId(newEmp.id);
    handleAddActivity(
      "Profile Created",
      newEmp.fullName,
      `Successfully created new verification profile [ID: ${newEmp.employeeId}] for ${newEmp.fullName} (${newEmp.title})`
    );
  };

  const handleUpdateEmployee = (updatedEmp: Employee) => {
    setEmployees(prev => prev.map(e => e.id === updatedEmp.id ? updatedEmp : e));
  };

  const handleDeleteEmployee = (id: string) => {
    const targetEmp = employees.find(e => e.id === id);
    setEmployees(prev => prev.filter(e => e.id !== id));
    setSelectedEmployeeId(null);
    if (targetEmp) {
      handleAddActivity(
        "Profile Deleted",
        targetEmp.fullName,
        `Permanently removed profile and associated ledger data of ${targetEmp.fullName}`
      );
    }
  };

  const handleImportSuccess = (updatedList: Employee[]) => {
    const addedCount = updatedList.length - employees.length;
    setEmployees(updatedList);
    handleAddActivity(
      "Bulk CSV Imported",
      "Spreadsheet",
      `Merged and imported bulk CSV entries. Current verified profile count matching: ${updatedList.length} total. (Added ${addedCount > 0 ? addedCount : 0} items)`
    );
  };

  const handleDownloadTemplate = () => {
    const template = getCSVTemplate();
    downloadCSV(template, "lca_payroll_import_template_standard.csv");
  };

  const selectedEmployee = employees.find(e => e.id === selectedEmployeeId);

  // Security pin lockscreen gate has precedence
  if (!isAuthenticated) {
    return <PinScreen onSuccess={handleAuthSuccess} logoSrc={LOGO_SRC} />;
  }

  return (
    <div id="desktop_app_frame" className={`fixed inset-0 bg-slate-50 flex flex-col font-sans overflow-hidden text-slate-800 ${theme === "dark" ? "dark" : ""}`}>
      
      {/* 1. Global Utility Header Bar */}
      <header id="desktop_app_header" className="h-20 bg-white border-b border-slate-200 shrink-0 flex items-center justify-between px-8 select-none relative z-10">
        
        {/* Brand identity & Logo */}
        <div className="flex items-center gap-5">
          <div className="relative group">
            <img
              id="app_header_logo"
              src={LOGO_SRC}
              alt="LGL Technologies Logo"
              className="h-12 object-contain bg-transparent shrink-0 hover:scale-102 transition-all duration-200 cursor-pointer"
              referrerPolicy="no-referrer"
              onClick={() => setSelectedEmployeeId(null)}
            />
          </div>

          <div className="h-8 w-px bg-slate-200 hidden sm:block" />

          <button
            id="view_dashboard_nav"
            onClick={() => setSelectedEmployeeId(null)}
            className={`w-11 h-11 transition-all rounded-xl cursor-pointer flex items-center justify-center border shrink-0 ${
              selectedEmployeeId === null
                ? "bg-indigo-650 border-indigo-700 text-white shadow-md shadow-indigo-600/15"
                : "border-slate-200 bg-white text-slate-600 hover:text-indigo-600 hover:bg-slate-50 hover:border-slate-300"
            }`}
            title="Go to Home / Dashboard"
          >
            <Home className="w-5 h-5" />
          </button>

          <div className="mr-2">
            <div className="flex items-center gap-2 leading-none">
              <span className="font-extrabold text-base tracking-tight font-sans flex items-center">
                <span className="text-indigo-650 font-extrabold">LGL</span> 
                <span className="text-indigo-500 font-extrabold ml-0.5">EMS</span>
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium tracking-tight block mt-1">
              Employee Expense & LCA Dashboard
            </span>
          </div>
        </div>

        {/* Center Indicators / Active View indicator */}
        <div id="header_middle_nav" className="hidden md:flex items-center gap-2.5">
          {selectedEmployeeId && (
            <div id="active_profile_crumb" className="px-3.5 py-1.5 bg-indigo-50 border border-indigo-100 text-indigo-700 font-semibold text-xs rounded-xl flex items-center gap-2">
              <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
              <span>Active Employee Profile: <strong className="font-bold text-indigo-650 text-indigo-600">{selectedEmployee?.fullName}</strong></span>
            </div>
          )}
        </div>

        {/* Desk Utilities Right column list */}
        <div id="desktop_top_controls" className="flex items-center gap-3 text-xs">

          <div className="flex items-center gap-2">
            <button
              id="bulk_import_header"
              onClick={() => setIsImportOpen(true)}
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-750 text-white transition-all rounded-xl font-bold flex items-center gap-2 shadow-sm shadow-indigo-600/10 cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>Bulk Import</span>
            </button>

            <button
              id="safety_lock_header"
              onClick={handleLockApp}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-all rounded-lg cursor-pointer flex items-center justify-center border border-slate-200 bg-slate-50"
              title="Lock System Immediately"
            >
              <Lock className="w-4 h-4 text-amber-500 animate-pulse" />
            </button>

            <button
              id="global_theme_toggle_header"
              onClick={() => setTheme(prev => prev === "light" ? "dark" : "light")}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-all rounded-lg cursor-pointer flex items-center justify-center border border-slate-200 bg-slate-50"
              title={`Switch to ${theme === "light" ? "Dark" : "Light"} mode`}
            >
              {theme === "light" ? (
                <Moon className="w-4 h-4 text-slate-500" />
              ) : (
                <Sun className="w-4 h-4 text-amber-500" />
              )}
            </button>
          </div>

        </div>

      </header>

      {/* 2. Main Desktop Layout Panel Frame */}
      <div id="desktop_app_body" className="flex-1 flex overflow-hidden bg-slate-50 relative">
        
        {/* Left Side: Unified search & listing navigator sidebar */}
        <EmployeeList
          employees={employees}
          selectedEmployeeId={selectedEmployeeId}
          onSelectEmployee={setSelectedEmployeeId}
          onAddEmployee={handleAddEmployee}
          year={selectedYear}
          calculationMode={calculationMode}
        />

        {/* Right Side: Main workspace details and graphs canvas */}
        <main id="main_desktop_workspace" className="flex-1 flex flex-col bg-slate-100 overflow-hidden">
          {selectedEmployee ? (
            /* Open dynamic specific employee card */
            <EmployeeDetailView
              employee={selectedEmployee}
              year={selectedYear}
              onBackToDashboard={() => setSelectedEmployeeId(null)}
              onUpdateEmployee={handleUpdateEmployee}
              onDeleteEmployee={handleDeleteEmployee}
              onAddActivity={handleAddActivity}
              layoutPreference={layoutPreference}
              calculationMode={calculationMode}
              onCalculationModeChange={setCalculationMode}
            />
          ) : (
            /* Root dashboard list with bento summary statistics */
            <DashboardView
              employees={employees}
              year={selectedYear}
              onYearChange={setSelectedYear}
              onSelectEmployee={setSelectedEmployeeId}
              onUpdateEmployee={handleUpdateEmployee}
              onAddActivity={handleAddActivity}
              calculationMode={calculationMode}
              onCalculationModeChange={setCalculationMode}
            />
          )}
        </main>

      </div>

      {/* 4. Collapsible Activity Report Drawer */}
      <div 
        id="audit_activities_timeline_tray"
        className={`bg-white border-t border-slate-200 transition-all duration-300 flex flex-col shrink-0 ${
          isTimelineExpanded ? "h-80" : "h-11"
        }`}
      >
        {/* Toggle Title Bar */}
        <div 
          onClick={() => setIsTimelineExpanded(!isTimelineExpanded)}
          className="h-11 px-6 bg-slate-900 text-white flex items-center justify-between cursor-pointer select-none hover:bg-slate-850 transition-colors"
        >
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="text-xs font-bold font-sans uppercase tracking-wider">
              Activity Report
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-slate-400 font-mono hidden md:inline">
              Click to {isTimelineExpanded ? "hide" : "view log report"}
            </span>
            {isTimelineExpanded ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronUp className="w-4 h-4 text-slate-400" />
            )}
          </div>
        </div>

        {/* Expanded View Content */}
        {isTimelineExpanded && (
          <div className="flex-1 flex flex-col bg-slate-50 min-h-0 overflow-hidden font-sans text-xs">
            {/* Control line */}
            <div className="px-6 py-2 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-[11px] select-none text-slate-600">
              <span className="font-semibold text-slate-500 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-indigo-500" />
                <span>Incremental Ledger History (Auto-logged, Chronological Trail)</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  if (window.confirm("Permanently wipe the activity log? This action cannot be undone.")) {
                    setActivities([
                      {
                        id: `wipe_${Date.now()}`,
                        timestamp: new Date().toISOString(),
                        actionType: "Report Cleared",
                        employeeName: "System",
                        details: "The activity report and edit log history were manually reset."
                      }
                    ]);
                  }
                }}
                className="hover:text-rose-600 font-semibold cursor-pointer text-[10px] bg-white border border-slate-200 rounded px-2 py-0.5 transition-all text-slate-600 shadow-sm"
              >
                Clear Report
              </button>
            </div>

            {/* Search & Filters block for Feature 5 */}
            <div className="px-6 py-2 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3.5 select-none shrink-0">
              <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
                {/* Search query field */}
                <div className="relative flex-1 max-w-xs">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none text-slate-450">
                    <Search className="w-3.5 h-3.5 text-slate-400" />
                  </span>
                  <input
                    type="text"
                    placeholder="Search details or name..."
                    value={timelineSearch}
                    onChange={(e) => setTimelineSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1 bg-slate-50/50 border border-slate-200 rounded-lg text-[11px] focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold placeholder:text-slate-400"
                  />
                  {timelineSearch && (
                    <button 
                      onClick={() => setTimelineSearch("")} 
                      className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-[10px] text-slate-450 hover:text-slate-650"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Filter dropdown */}
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500">
                  <span>Action:</span>
                  <select
                    value={timelineFilter}
                    onChange={(e) => setTimelineFilter(e.target.value)}
                    className="px-2 py-1 bg-slate-50 border border-slate-150 rounded-lg text-[11px] font-bold text-slate-700 outline-none cursor-pointer hover:bg-slate-100/80 transition-colors"
                  >
                    <option value="All">All Actions</option>
                    <option value="Created">Created</option>
                    <option value="Edited">Modified</option>
                    <option value="Deleted">Deleted / Reset</option>
                    <option value="Imported">Imports</option>
                  </select>
                </div>
              </div>

              {/* Export Logs button */}
              <button
                type="button"
                onClick={handleExportTimeline}
                className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-100 rounded-lg text-[11px] font-extrabold flex items-center gap-1 cursor-pointer shadow-xs transition-all"
              >
                <Download className="w-3 h-3" />
                <span>Export Audit to CSV</span>
              </button>
            </div>

            {/* List panel */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50 relative">
              {filteredActivities.length === 0 ? (
                <div className="text-center italic text-slate-400 py-10">
                  No registered actions matched the filter criteria.
                </div>
              ) : (
                <div className="relative border-l-2 border-indigo-100 pl-6 ml-3 space-y-4">
                  {filteredActivities.map((act) => {
                    const d = new Date(act.timestamp);
                    const localTime = d.toISOString().replace("T", " ").slice(0, 19) + " UTC";
                    
                    // Categorize colors
                    let badgeClass = "bg-slate-100 border-slate-200 text-slate-700";
                    if (act.actionType.includes("Created") || act.actionType.includes("Logged") || act.actionType.includes("Added")) {
                      badgeClass = "bg-emerald-50 border-emerald-155/30 text-emerald-700";
                    } else if (act.actionType.includes("Edited") || act.actionType.includes("Updated") || act.actionType.includes("Modified")) {
                      badgeClass = "bg-indigo-50 border-indigo-155/30 text-indigo-700";
                    } else if (act.actionType.includes("Deleted") || act.actionType.includes("Cleared") || act.actionType.includes("Removed")) {
                      badgeClass = "bg-rose-50 border-rose-155/30 text-rose-700";
                    } else if (act.actionType.includes("Imported")) {
                      badgeClass = "bg-purple-50 border-purple-155/30 text-purple-700";
                    }

                    return (
                      <div key={act.id} className="relative group select-text">
                        {/* Bullet circle dot */}
                        <span className="absolute -left-[31px] top-1.5 w-3.5 h-3.5 rounded-full border-2 border-indigo-400 bg-white group-hover:scale-110 transition-transform flex items-center justify-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        </span>

                        {/* Event Content Cards */}
                        <div className="p-3 bg-white border border-slate-200 rounded-lg shadow-sm hover:border-indigo-200 transition-colors">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pb-1 border-b border-slate-100 mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-0.5 border text-[9px] font-bold uppercase rounded ${badgeClass}`}>
                                {act.actionType}
                              </span>
                              {act.employeeName !== "System" && act.employeeName !== "Database" && act.employeeName !== "Spreadsheet" && (
                                <span className="font-bold text-slate-800 text-[11px] flex items-center gap-1">
                                  <User className="w-3.5 h-3.5 text-slate-400 inline" />
                                  <span>{act.employeeName}</span>
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">{localTime}</span>
                          </div>
                          <p className="text-[11px] text-slate-600 font-medium leading-relaxed select-text">
                            {act.details}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 3. Bulk CSV import alignment modal */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        employees={employees}
        onImportComplete={handleImportSuccess}
      />

    </div>
  );
}
