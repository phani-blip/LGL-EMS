/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Employee, MonthlyBreakdown, EmployeeSummary, LCARecord, PayrollRecord, ExpenseTransaction } from "../types";

export const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

/**
 * Returns number of days in a specific month of a specific year
 * (month is 1-indexed, i.e., 1 = Jan, 12 = Dec)
 */
export function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

/**
 * Checks if firstDateStr is on or before secondDateStr
 */
export function isBeforeOrEqual(firstDateStr: string, secondDateStr: string): boolean {
  return new Date(firstDateStr) <= new Date(secondDateStr);
}

/**
 * Formats Date to YYYY-MM-DD
 */
export function formatDate(date: Date): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

/**
 * Formats YYYY-MM-DD or other date formats into MM/DD/YYYY format.
 */
export function formatDateToMDY(dateStr: string): string {
  if (!dateStr) return "";
  // If already in MM/DD/YYYY format
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) {
    return dateStr;
  }
  const parts = dateStr.split("-");
  if (parts.length === 3) {
    const first = parts[0];
    const second = parts[1];
    const third = parts[2];
    if (first.length === 4) {
      return `${second}/${third}/${first}`;
    }
  }
  try {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) {
      const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
      const dd = String(d.getUTCDate()).padStart(2, "0");
      const yyyy = d.getUTCFullYear();
      return `${mm}/${dd}/${yyyy}`;
    }
  } catch (e) {}
  return dateStr;
}

/**
 * Finds the active LCA Record for a specific date YYYY-MM-DD
 */
export function findActiveLCARecord(lcaRecords: LCARecord[], dateStr: string): LCARecord | null {
  if (!lcaRecords || lcaRecords.length === 0) return null;
  
  // Sort records by effectiveFrom ascending
  const sorted = [...lcaRecords].sort((a, b) => 
    new Date(a.effectiveFrom).getTime() - new Date(b.effectiveFrom).getTime()
  );

  let activeRecord: LCARecord | null = null;
  const targetTime = new Date(dateStr).getTime();

  for (const record of sorted) {
    const recordTime = new Date(record.effectiveFrom).getTime();
    if (recordTime <= targetTime) {
      activeRecord = record;
    } else {
      break;
    }
  }

  // If no record is effective yet, standard practice is to use the earliest one
  return activeRecord || sorted[0];
}

/**
 * Calculates expected prorated LCA wage for a specific month of a specific year
 * based on LCA records and mid-year timing changes.
 */
export function calculateExpectedMonthlyLCA(
  lcaRecords: LCARecord[], 
  year: number, 
  month: number
): { expectedLCA: number; breakdownNotes: string } {
  if (!lcaRecords || lcaRecords.length === 0) {
    return { expectedLCA: 0, breakdownNotes: "No LCA record set" };
  }

  const daysInMonth = getDaysInMonth(year, month);
  let totalMonthlyExpected = 0;
  
  // Track continuous segments of different rates
  const segments: { rate: number; days: number; startDay: number; endDay: number }[] = [];
  let currentSegmentRate: number | null = null;
  let segmentStartDay = 1;

  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const active = findActiveLCARecord(lcaRecords, dateStr);
    const rate = active ? active.annualWage : 0;

    if (day === 1) {
      currentSegmentRate = rate;
    } else if (rate !== currentSegmentRate) {
      segments.push({
        rate: currentSegmentRate || 0,
        days: day - segmentStartDay,
        startDay: segmentStartDay,
        endDay: day - 1,
      });
      currentSegmentRate = rate;
      segmentStartDay = day;
    }

    if (day === daysInMonth) {
      segments.push({
        rate: currentSegmentRate || 0,
        days: day - segmentStartDay + 1,
        startDay: segmentStartDay,
        endDay: day,
      });
    }
  }

  // Sum up prorated amounts for all segments
  // Formula: Sum of ((AnnualRate / 12) * (DaysInSegment / TotalDaysInMonth))
  const notesList: string[] = [];
  for (const seg of segments) {
    const monthProportion = seg.days / daysInMonth;
    const monthlyRate = seg.rate / 12;
    const proratedAmount = monthlyRate * monthProportion;
    totalMonthlyExpected += proratedAmount;

    if (segments.length > 1 && seg.rate > 0) {
      notesList.push(
        `${seg.days} days @ $${seg.rate.toLocaleString("en-US", { minimumFractionDigits: 2 })} ($${proratedAmount.toLocaleString("en-US", { maximumFractionDigits: 2 })})`
      );
    }
  }

  let finalNotes = "";
  if (segments.length > 1) {
    finalNotes = "Prorated: " + notesList.join(" | ");
  } else if (segments.length === 1 && segments[0].rate > 0) {
    finalNotes = `Standard monthly LCA ($${(segments[0].rate / 12).toLocaleString("en-US", { minimumFractionDigits: 2 })}/mo)`;
  } else {
    finalNotes = "No active LCA rate";
  }

  return {
    expectedLCA: Number(totalMonthlyExpected.toFixed(2)),
    breakdownNotes: finalNotes,
  };
}

/**
 * Computes complete analysis for one employee for a given year
 */
export function calculateEmployeeSummary(
  employee: Employee, 
  year: number,
  calculationMode: "ytd" | "full" = "ytd"
): EmployeeSummary {
  const breakdown: MonthlyBreakdown[] = [];
  let expectedAnnualLCA = 0;
  let actualAnnualPayroll = 0;
  let hasDiscrepancies = false;

  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth() + 1; // 1-indexed

  for (let m = 1; m <= 12; m++) {
    const { expectedLCA, breakdownNotes } = calculateExpectedMonthlyLCA(employee.lcaRecords, year, m);
    
    // Find matching payroll entries for this year and month
    const payrollEntries = employee.payrollRecords.filter(
      p => p.year === year && p.month === m
    );
    const actualPayroll = payrollEntries.reduce((sum, p) => sum + p.amount, 0);

    const difference = actualPayroll - expectedLCA;
    const isMatching = difference >= 0; // compliant if payroll matches or exceeds LCA

    const isFuture = (year === currentYear && m > currentMonth) || (year > currentYear);
    const isYtdExcluded = calculationMode === "ytd" && isFuture;

    if (!isMatching && expectedLCA > 0 && !isYtdExcluded) {
      hasDiscrepancies = true;
    }

    const actualPayrollPercent = expectedLCA > 0 ? (actualPayroll / expectedLCA) * 100 : 100;

    breakdown.push({
      monthName: MONTH_NAMES[m - 1],
      monthNumber: m,
      year,
      expectedLCAWage: expectedLCA,
      actualPayroll,
      actualPayrollPercent: Number(actualPayrollPercent.toFixed(1)),
      difference: Number(difference.toFixed(2)),
      isMatching: isYtdExcluded ? true : isMatching,
      notes: isYtdExcluded ? `${breakdownNotes} (Future Excluded)` : breakdownNotes,
      isFuture,
    });

    if (!isYtdExcluded) {
      expectedAnnualLCA += expectedLCA;
      actualAnnualPayroll += actualPayroll;
    }
  }

  const annualDifference = actualAnnualPayroll - expectedAnnualLCA;

  return {
    employee,
    expectedAnnualLCA: Number(expectedAnnualLCA.toFixed(2)),
    actualAnnualPayroll: Number(actualAnnualPayroll.toFixed(2)),
    annualDifference: Number(annualDifference.toFixed(2)),
    hasDiscrepancies,
    monthlyBreakdown: breakdown,
  };
}

/**
 * Downloads data as a CSV file in the browser
 */
export function downloadCSV(csvContent: string, fileName: string) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", fileName);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Generates the import template CSV content
 */
export function getCSVTemplate(): string {
  const headers = [
    "Employee ID",
    "Full Name",
    "Email",
    "Job Title",
    "Department",
    "Annual LCA Wage",
    "LCA Effective From (YYYY-MM-DD)",
    "LCA Expiration Date (YYYY-MM-DD)",
    "LCA Case Number",
    "Client Address Line 1",
    "Client Address Line 2",
    "Client City",
    "Client County",
    "Client State",
    "Client Zip",
    "Residence Address Line 1",
    "Residence Address Line 2",
    "Residence City",
    "Residence County",
    "Residence State",
    "Residence Zip",
    "Payroll Year",
    "Payroll Month (1-12)",
    "Payroll Amount",
  ];
  const demoRows = [
    "EMP-101,John Doe,john.doe@techcorp.com,Senior Engineer,Engineering,95000,2026-01-01,2029-12-31,I-200-24125-123456,1 Oracle Way,,Redwood City,San Mateo,CA,94065,450 Sutter St,,San Francisco,San Francisco,CA,94108,2026,1,7916.67",
    "EMP-101,John Doe,john.doe@techcorp.com,Senior Engineer,Engineering,101000,2026-06-12,2029-12-31,I-200-24125-123456,1 Oracle Way,,Redwood City,San Mateo,CA,94065,450 Sutter St,,San Francisco,San Francisco,CA,94108,2026,6,8250.00",
    "EMP-102,Sarah Connor,sarah@techcorp.com,Security Lead,Operations,110000,2026-01-01,2028-06-30,I-200-24125-999999,1600 Amphitheatre Pkwy,,Mountain View,Santa Clara,CA,94043,201 Folsom St,,San Francisco,San Francisco,CA,94105,2026,1,9166.67",
  ];
  return [headers.join(","), ...demoRows].join("\n");
}

/**
 * Exports multiple employee summaries and their comparison matrix to a CSV file
 */
export function exportDashboardToCSV(summaries: EmployeeSummary[], year: number): string {
  const rows = [
    `LCA vs Payroll Audit Dashboard Report (Year: ${year})`,
    "Generated: " + new Date().toLocaleDateString(),
    "",
    "Employee ID,Full Name,Email,Job Title,Expected Annual LCA,Actual Annual Payroll,Annual Difference,Compliance Status"
  ];

  for (const s of summaries) {
    const status = s.annualDifference >= 0 ? "Compliant" : "Non-Compliant (Underpaid)";
    rows.push(
      [
        s.employee.employeeId,
        `"${s.employee.fullName.replace(/"/g, '""')}"`,
        s.employee.email,
        `"${s.employee.title.replace(/"/g, '""')}"`,
        s.expectedAnnualLCA,
        s.actualAnnualPayroll,
        s.annualDifference,
        status,
      ].join(",")
    );
  }

  return rows.join("\n");
}

/**
 * Exports details of a single employee to CSV
 */
export function exportEmployeeDetailToCSV(summary: EmployeeSummary, year: number): string {
  const e = summary.employee;
  const rows = [
    `Employee LCA compliance Report (${year})`,
    `Employee: ${e.fullName} (${e.employeeId})`,
    `Email: ${e.email}`,
    `Title: ${e.title}`,
    "",
    "LCA RECORDS HISTORY",
    "Annual Wage,Effective From Date",
    ...e.lcaRecords.map(r => `${r.annualWage},${r.effectiveFrom}`),
    "",
    "MONTHLY ANALYSIS BREAKDOWN",
    "Month,Expected LCA,Actual Payroll Paid,Monthly Difference,Compliance,Calculation Notes"
  ];

  for (const m of summary.monthlyBreakdown) {
    const status = m.difference >= 0 ? "Compliant" : "Underpaid";
    rows.push(
      [
        m.monthName,
        m.expectedLCAWage,
        m.actualPayroll,
        m.difference,
        status,
        `"${m.notes.replace(/"/g, '""')}"`
      ].join(",")
    );
  }

  return rows.join("\n");
}

/**
 * Generates an explanation message for any automated calculations used within an expense transaction
 */
export function generateCalculationExplanation(txn: ExpenseTransaction): string {
  const custom = txn.customFields || {};
  const hasProject = "Project" in custom && custom["Project"];
  const hasHrs = "Hrs" in custom && custom["Hrs"];
  const hasRate = "Rate" in custom && custom["Rate"];
  const hasTotal = "Total" in custom && custom["Total"];
  
  if (hasHrs || hasRate || hasTotal || hasProject) {
    const project = custom["Project"] || "N/A";
    const hrs = custom["Hrs"] || "0.00";
    const rate = custom["Rate"] || "$0.00";
    const total = custom["Total"] || "$0.00";
    const empTax = custom["Employee Tax"] || "$0.00";
    const erTax = custom["Employer Tax"] || "$0.00";
    const ins = custom["Insurance"] || "$0.00";
    
    return `Worksheet details for Project [${project}]: Base calculation = ${hrs} hrs * ${rate} = ${total}. Deductions applied: Employee Tax (${empTax}), Employer Tax (${erTax}), Insurance (${ins}). Net Transaction Value: $${Math.abs(txn.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}.`;
  }
  
  return "Standard direct entry (no custom calculations worksheet applied).";
}

/**
 * Exports expenses of a single employee to CSV
 */
export function exportEmployeeExpensesToCSV(employee: Employee, year: number): string {
  const e = employee;
  const txns = e.expenseTransactions || [];
  
  // Helper to extract year from date string (supports MM/DD/YYYY and YYYY-MM-DD)
  const getTransactionYear = (dateStr: string): number => {
    if (!dateStr) return 0;
    const partsMdy = dateStr.split("/");
    if (partsMdy.length === 3) return parseInt(partsMdy[2]);
    const partsYmd = dateStr.split("-");
    if (partsYmd.length === 3 && partsYmd[0].length === 4) return parseInt(partsYmd[0]);
    try {
      return new Date(dateStr).getFullYear();
    } catch {
      return 0;
    }
  };

  const filteredTxns = txns.filter(txn => getTransactionYear(txn.date) === year);

  // Split paid vs received
  // Paid: amount < 0 (disbursed out)
  const paidTxns = filteredTxns.filter(txn => txn.amount < 0);
  // Received: amount > 0 (returned back / recoupments)
  const receivedTxns = filteredTxns.filter(txn => txn.amount > 0);

  // Calculations
  const totalPaid = paidTxns.reduce((sum, t) => sum + Math.abs(t.amount), 0);
  const totalReceived = receivedTxns.reduce((sum, t) => sum + Math.abs(t.amount), 0);
  const netOutstandingBalance = totalPaid - totalReceived;

  const escape = (val: any): string => {
    if (val === undefined || val === null) return "";
    const str = String(val);
    return `"${str.replace(/"/g, '""')}"`;
  };

  const rows = [
    `Employee Activity Expense Advance & Offset Ledger (Year: ${year})`,
    `Employee: ${e.fullName} (${e.employeeId})`,
    `Email: ${e.email}`,
    `Job Title: ${e.title}`,
    "Generated: " + new Date().toLocaleDateString(),
    "",
    "EXPENSE LEDGER SUMMARY BALANCE OVERVIEW (USD):",
    `"Total LGL Paid (Disbursed Outwards / Cash Advances)","$${totalPaid.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    `"Total LGL Received (Returned Inwards / Offset / Recoupment)","$${totalReceived.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    `"Final Outstanding Balance (Net Cash Paid Less Received)","$${netOutstandingBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    "",
    "SIDE-BY-SIDE LEDGER TRANSACTIONS:",
    [
      "LGL PAID (DISBURSED OUTWARD)", "", "", "", "",
      "",
      "LGL RECEIVED (RETURNED BACK / RECOUPMENT)", "", "", "", ""
    ].join(","),
    [
      "Paid ID", "Paid Date", "Paid Details", "Paid Amount (USD)", "Paid Worksheet & Explanation",
      "",
      "Received ID", "Received Date", "Received Details", "Received Amount (USD)", "Received Worksheet & Explanation"
    ].join(",")
  ];

  const maxRows = Math.max(paidTxns.length, receivedTxns.length);

  for (let i = 0; i < maxRows; i++) {
    const pTx = paidTxns[i];
    const rTx = receivedTxns[i];

    let paidParts: string[];
    if (pTx) {
      paidParts = [
        escape(pTx.id),
        escape(formatDateToMDY(pTx.date)),
        escape(pTx.details),
        escape(`$${Math.abs(pTx.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}`),
        escape(generateCalculationExplanation(pTx))
      ];
    } else {
      paidParts = ["", "", "", "", ""];
    }

    let receivedParts: string[];
    if (rTx) {
      receivedParts = [
        escape(rTx.id),
        escape(formatDateToMDY(rTx.date)),
        escape(rTx.details),
        escape(`$${Math.abs(rTx.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}`),
        escape(generateCalculationExplanation(rTx))
      ];
    } else {
      receivedParts = ["", "", "", "", ""];
    }

    const row = [...paidParts, "", ...receivedParts].join(",");
    rows.push(row);
  }

  return rows.join("\n");
}

/**
 * Parses individual rows of a CSV import
 */
export function parseCSV(text: string): Record<string, any>[] {
  const lines = text.split(/\r?\n/);
  if (lines.length === 0) return [];

  const headers = lines[0].split(",").map(h => h.trim().replace(/^"|"$/g, ""));
  const records: Record<string, string>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Fast CSV comma splitting handling simple quoted fields
    const values: string[] = [];
    let insideQuotes = false;
    let currentValue = "";

    for (let c = 0; c < line.length; c++) {
      const char = line[c];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(currentValue.trim());
        currentValue = "";
      } else {
        currentValue += char;
      }
    }
    values.push(currentValue.trim());

    // Clean up quotes of parsed values
    const cleanValues = values.map(v => v.replace(/^"|"$/g, ""));

    const item: Record<string, string> = {};
    headers.forEach((hdr, idx) => {
      if (idx < cleanValues.length) {
        item[hdr] = cleanValues[idx];
      } else {
        item[hdr] = "";
      }
    });
    records.push(item);
  }

  return records;
}

/**
 * Generates the import template CSV content for Expenses
 */
export function getExpenseCSVTemplate(): string {
  const headers = [
    "Employee ID",
    "Full Name",
    "Email",
    "Job Title",
    "Department",
    "Expense Date",
    "Expense Details",
    "Expense Amount",
    "Category",
    "Reference ID"
  ];
  const demoRows = [
    "EMP-101,John Doe,john.doe@techcorp.com,Senior Engineer,Engineering,05/14/2026,Company disbursed advance cash (I gave $500),500.00,Travel Advance,TXN_501",
    "EMP-101,John Doe,john.doe@techcorp.com,Senior Engineer,Engineering,05/17/2026,Employee paid back unused balance (Alex returned $200),-200.00,Reimbursement Offset,TXN_502"
  ];
  return [headers.join(","), ...demoRows].join("\n");
}

/**
 * Exports all expense transactions across all employees to a CSV file
 */
export function exportExpensesToCSV(employees: Employee[]): string {
  // Let's grab all transactions across all employees and split them
  interface Item {
    emp: Employee;
    txn: ExpenseTransaction;
  }
  const allTxns: Item[] = [];
  employees.forEach(emp => {
    (emp.expenseTransactions || []).forEach(txn => {
      allTxns.push({ emp, txn });
    });
  });

  // Sort them chronologically by date
  allTxns.sort((a, b) => {
    const timeA = new Date(a.txn.date).getTime() || 0;
    const timeB = new Date(b.txn.date).getTime() || 0;
    return timeA - timeB;
  });

  // Split paid vs received
  // Paid (amount < 0)
  const paidItems = allTxns.filter(item => item.txn.amount < 0);
  // Received (amount > 0)
  const receivedItems = allTxns.filter(item => item.txn.amount > 0);

  // Calculations
  const totalPaid = paidItems.reduce((sum, item) => sum + Math.abs(item.txn.amount), 0);
  const totalReceived = receivedItems.reduce((sum, item) => sum + Math.abs(item.txn.amount), 0);
  const netOutstandingBalance = totalPaid - totalReceived;

  const escape = (val: any): string => {
    if (val === undefined || val === null) return "";
    const str = String(val);
    return `"${str.replace(/"/g, '""')}"`;
  };

  const rows = [
    "All Employees Expense Advance & Offset Compliance Ledger",
    "Generated: " + new Date().toLocaleDateString(),
    "",
    "TOTAL COMPLIANCE LEDGER SUMMARY BALANCE OVERVIEW (USD):",
    `"Total LGL Paid (Disbursed Out across all employees)","$${totalPaid.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    `"Total LGL Received (Returned Back across all employees)","$${totalReceived.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    `"Final Outstanding Balance (Total Net Due for all employees)","$${netOutstandingBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}"`,
    "",
    "SIDE-BY-SIDE ALL-EMPLOYEE LEDGER TRANSACTIONS:",
    [
      "LGL PAID (DISBURSED OUTWARDS)", "", "", "", "", "", "",
      "",
      "LGL RECEIVED (RETURNED INWARDS / RECOUPMENTS)", "", "", "", "", "", ""
    ].join(","),
    [
      "Emp ID", "Emp Name", "Paid ID", "Paid Date", "Paid Details", "Paid Amount (USD)", "Paid Worksheet & Explanation",
      "",
      "Emp ID", "Emp Name", "Received ID", "Received Date", "Received Details", "Received Amount (USD)", "Received Worksheet & Explanation"
    ].join(",")
  ];

  const maxRows = Math.max(paidItems.length, receivedItems.length);

  for (let i = 0; i < maxRows; i++) {
    const pItem = paidItems[i];
    const rItem = receivedItems[i];

    let paidParts: string[];
    if (pItem) {
      paidParts = [
        escape(pItem.emp.employeeId),
        escape(pItem.emp.fullName),
        escape(pItem.txn.id),
        escape(formatDateToMDY(pItem.txn.date)),
        escape(pItem.txn.details),
        escape(`$${Math.abs(pItem.txn.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}`),
        escape(generateCalculationExplanation(pItem.txn))
      ];
    } else {
      paidParts = ["", "", "", "", "", "", ""];
    }

    let receivedParts: string[];
    if (rItem) {
      receivedParts = [
        escape(rItem.emp.employeeId),
        escape(rItem.emp.fullName),
        escape(rItem.txn.id),
        escape(formatDateToMDY(rItem.txn.date)),
        escape(rItem.txn.details),
        escape(`$${Math.abs(rItem.txn.amount).toLocaleString("en-US", { minimumFractionDigits: 2 })}`),
        escape(generateCalculationExplanation(rItem.txn))
      ];
    } else {
      receivedParts = ["", "", "", "", "", "", ""];
    }

    const row = [...paidParts, "", ...receivedParts].join(",");
    rows.push(row);
  }

  return rows.join("\n");
}

/**
 * Imports CSV and merges it into our Employee state schema (supports LCA, Payroll, and Expenses)
 */
export function importEmployeesFromCSV(csvText: string, currentEmployees: Employee[]): {
  successList: string[];
  errors: string[];
  updatedEmployees: Employee[];
} {
  const records = parseCSV(csvText);
  if (records.length === 0) {
    return { successList: [], errors: ["CSV file is empty or missing headers."], updatedEmployees: currentEmployees };
  }

  const errors: string[] = [];
  const successList: string[] = [];
  
  // Create a working map keyed by employeeId (case insensitive)
  const empMap = new Map<string, Employee>();
  currentEmployees.forEach(e => {
    // Deep clone to avoid mutating state incorrectly
    empMap.set(e.employeeId.toUpperCase(), JSON.parse(JSON.stringify(e)));
  });

  let rowNum = 1;
  for (const raw of records) {
    rowNum++;
    const empId = (raw["Employee ID"] || raw["employeeId"] || "").trim();
    const fullName = (raw["Full Name"] || raw["fullName"] || "").trim();
    const email = (raw["Email"] || raw["email"] || "").trim();
    const title = (raw["Job Title"] || raw["JobTitle"] || raw["title"] || "").trim();
    const department = (raw["Department"] || raw["department"] || "").trim();
    
    const annualWageStr = (raw["Annual LCA Wage"] || raw["annualWage"] || "").trim();
    const effectiveFromStr = (raw["LCA Effective From (YYYY-MM-DD)"] || raw["effectiveFrom"] || "").trim();
    
    // New fields
    const lcaNumber = (raw["LCA Case Number"] || raw["lcaNumber"] || "").trim();
    const lcaExpirationStr = (raw["LCA Expiration Date (YYYY-MM-DD)"] || raw["tillDate"] || "").trim();
    const clientAddress1 = (raw["Client Address Line 1"] || raw["clientAddress1"] || "").trim();
    const clientAddress2 = (raw["Client Address Line 2"] || raw["clientAddress2"] || "").trim();
    const clientCity = (raw["Client City"] || raw["clientCity"] || "").trim();
    const clientCounty = (raw["Client County"] || raw["clientCounty"] || "").trim();
    const clientState = (raw["Client State"] || raw["clientState"] || "").trim();
    const clientZip = (raw["Client Zip"] || raw["clientZip"] || "").trim();
    const residenceAddress1 = (raw["Residence Address Line 1"] || raw["residenceAddress1"] || "").trim();
    const residenceAddress2 = (raw["Residence Address Line 2"] || raw["residenceAddress2"] || "").trim();
    const residenceCity = (raw["Residence City"] || raw["residenceCity"] || "").trim();
    const residenceCounty = (raw["Residence County"] || raw["residenceCounty"] || "").trim();
    const residenceState = (raw["Residence State"] || raw["residenceState"] || "").trim();
    const residenceZip = (raw["Residence Zip"] || raw["residenceZip"] || "").trim();

    const payrollYearStr = (raw["Payroll Year"] || "").trim();
    const payrollMonthStr = (raw["Payroll Month (1-12)"] || "").trim();
    const payrollAmountStr = (raw["Payroll Amount"] || "").trim();

    // Expense attributes
    const expenseDateStr = (raw["Expense Date"] || raw["expenseDate"] || "").trim();
    const expenseDetailsStr = (raw["Expense Details"] || raw["Expense Description"] || raw["expenseDetails"] || "").trim();
    const expenseAmountStr = (raw["Expense Amount"] || raw["expenseAmount"] || "").trim();

    if (!empId) {
      errors.push(`Row ${rowNum}: Employee ID is required.`);
      continue;
    }

    const key = empId.toUpperCase();
    let emp = empMap.get(key);

    if (!emp) {
      if (!fullName) {
        errors.push(`Row ${rowNum}: Creating new employee requires 'Full Name'.`);
        continue;
      }
      emp = {
        id: `emp_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        employeeId: empId,
        fullName,
        email,
        title: title || "Associate",
        department: department || "Operations",
        lcaRecords: [],
        payrollRecords: [],
        expenseTransactions: [],
        expenseColumns: [],
      };
      empMap.set(key, emp);
      successList.push(`Created Employee ${fullName} (${empId})`);
    } else {
      // If employee exists, update their metadata if provided in the CSV
      if (fullName) emp.fullName = fullName;
      if (email) emp.email = email;
      if (title) emp.title = title;
      if (department) emp.department = department;
    }

    // Process LCA Record if present
    if (annualWageStr && effectiveFromStr) {
      const wage = parseFloat(annualWageStr.replace(/[^0-9.]/g, ""));
      if (isNaN(wage)) {
        errors.push(`Row ${rowNum}: Invalid LCA Wage format '${annualWageStr}' for ${empId}`);
      } else {
        // Compile Addresses if fields are present
        let clientAddress: string | undefined = undefined;
        if (clientAddress1) {
          clientAddress = [
            clientAddress1,
            clientAddress2 || "",
            clientCity || "",
            clientCounty ? (clientCounty.toLowerCase().endsWith("county") ? clientCounty : `${clientCounty} County`) : "",
            clientState || "",
            clientZip || ""
          ].filter(Boolean).join(", ");
        }

        let residenceAddress: string | undefined = undefined;
        if (residenceAddress1) {
          residenceAddress = [
            residenceAddress1,
            residenceAddress2 || "",
            residenceCity || "",
            residenceCounty ? (residenceCounty.toLowerCase().endsWith("county") ? residenceCounty : `${residenceCounty} County`) : "",
            residenceState || "",
            residenceZip || ""
          ].filter(Boolean).join(", ");
        }

        // Find existing record with same effectiveFrom
        const existingLCA = emp.lcaRecords.find(r => r.effectiveFrom === effectiveFromStr);
        if (existingLCA) {
          existingLCA.annualWage = wage;
          if (lcaNumber) existingLCA.lcaNumber = lcaNumber;
          if (lcaExpirationStr) existingLCA.tillDate = lcaExpirationStr;
          if (clientAddress1) {
            existingLCA.clientAddress1 = clientAddress1;
            existingLCA.clientAddress2 = clientAddress2 || undefined;
            existingLCA.clientCity = clientCity || undefined;
            existingLCA.clientCounty = clientCounty || undefined;
            existingLCA.clientState = clientState || undefined;
            existingLCA.clientZip = clientZip || undefined;
            existingLCA.clientAddress = clientAddress;
          }
          if (residenceAddress1) {
            existingLCA.residenceAddress1 = residenceAddress1;
            existingLCA.residenceAddress2 = residenceAddress2 || undefined;
            existingLCA.residenceCity = residenceCity || undefined;
            existingLCA.residenceCounty = residenceCounty || undefined;
            existingLCA.residenceState = residenceState || undefined;
            existingLCA.residenceZip = residenceZip || undefined;
            existingLCA.residenceAddress = residenceAddress;
          }
        } else {
          emp.lcaRecords.push({
            id: `lca_${Math.random().toString(36).substr(2, 5)}`,
            annualWage: wage,
            effectiveFrom: effectiveFromStr,
            lcaNumber: lcaNumber || undefined,
            tillDate: lcaExpirationStr || undefined,
            clientAddress1: clientAddress1 || undefined,
            clientAddress2: clientAddress2 || undefined,
            clientCity: clientCity || undefined,
            clientCounty: clientCounty || undefined,
            clientState: clientState || undefined,
            clientZip: clientZip || undefined,
            clientAddress,
            residenceAddress1: residenceAddress1 || undefined,
            residenceAddress2: residenceAddress2 || undefined,
            residenceCity: residenceCity || undefined,
            residenceCounty: residenceCounty || undefined,
            residenceState: residenceState || undefined,
            residenceZip: residenceZip || undefined,
            residenceAddress,
          });
        }
      }
    }

    // Process Payroll Record if present
    if (payrollYearStr && payrollMonthStr && payrollAmountStr) {
      const pYear = parseInt(payrollYearStr);
      const pMonth = parseInt(payrollMonthStr);
      const pAmount = parseFloat(payrollAmountStr.replace(/[^0-9.]/g, ""));

      if (isNaN(pYear) || isNaN(pMonth) || pMonth < 1 || pMonth > 12 || isNaN(pAmount)) {
        errors.push(`Row ${rowNum}: Invalid payroll record entries (Year/Month/Amount) for ${empId}`);
      } else {
        const existingPayroll = emp.payrollRecords.find(p => p.year === pYear && p.month === pMonth);
        if (existingPayroll) {
          existingPayroll.amount = pAmount;
        } else {
          emp.payrollRecords.push({
            id: `pay_${Math.random().toString(36).substr(2, 5)}`,
            year: pYear,
            month: pMonth,
            amount: pAmount,
          });
        }
      }
    }

    // Process Expense Record if present
    if (expenseDateStr && expenseDetailsStr && expenseAmountStr) {
      // Allow negative amounts for paid back
      const expAmt = parseFloat(expenseAmountStr.replace(/[^0-9.-]/g, ""));
      if (isNaN(expAmt)) {
        errors.push(`Row ${rowNum}: Invalid expense amount '${expenseAmountStr}' for ${empId}`);
      } else {
        const convertedDate = formatDateToMDY(expenseDateStr);

        // Map any dynamic custom columns
        const standardKeys = new Set([
          "Employee ID", "employeeId",
          "Full Name", "fullName",
          "Email", "email",
          "Job Title", "JobTitle", "title",
          "Department", "department",
          "Annual LCA Wage", "annualWage",
          "LCA Effective From (YYYY-MM-DD)", "effectiveFrom",
          "Payroll Year", "Payroll Month (1-12)", "Payroll Amount",
          "Expense Date", "expenseDate",
          "Expense Details", "Expense Description", "expenseDetails",
          "Expense Amount", "expenseAmount"
        ]);

        const customFields: Record<string, string> = {};
        const empCols = emp.expenseColumns || [];
        const newCols = [...empCols];

        Object.keys(raw).forEach(key => {
          if (!standardKeys.has(key)) {
            const val = (raw[key] || "").trim();
            if (val) {
              customFields[key] = val;
              if (!newCols.includes(key)) {
                newCols.push(key);
              }
            }
          }
        });

        emp.expenseColumns = newCols;
        if (!emp.expenseTransactions) {
          emp.expenseTransactions = [];
        }

        emp.expenseTransactions.push({
          id: `exp_${Math.random().toString(36).substr(2, 5)}_${Date.now()}`,
          date: convertedDate,
          details: expenseDetailsStr,
          amount: expAmt,
          customFields
        });

        successList.push(`Logged Expense of $${expAmt} on ${convertedDate} for ${emp.fullName}`);
      }
    }
  }

  return {
    successList,
    errors,
    updatedEmployees: Array.from(empMap.values()),
  };
}

export interface ConsecutiveUnderpaidAlert {
  hasAlert: boolean;
  consecutiveMonths: string[];
}

/**
 * Helper to identify employees with 'Underpaid' status for more than 2 consecutive months (3 or more)
 */
export function detectConsecutiveUnderpaid(summary: EmployeeSummary, limit: number = 3): ConsecutiveUnderpaidAlert {
  let currentStreak: string[] = [];
  let longestStreak: string[] = [];

  for (const month of summary.monthlyBreakdown) {
    const isUnderpaid = !month.isMatching && month.expectedLCAWage > 0;
    if (isUnderpaid) {
      currentStreak.push(month.monthName);
      if (currentStreak.length > longestStreak.length) {
        longestStreak = [...currentStreak];
      }
    } else {
      currentStreak = [];
    }
  }

  return {
    hasAlert: longestStreak.length >= limit,
    consecutiveMonths: longestStreak,
  };
}

